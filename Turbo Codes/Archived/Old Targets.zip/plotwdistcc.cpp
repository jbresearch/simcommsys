#include "rscc.h"
#include "nrcc.h"
#include "timer.h"
#include "itfunc.h"

#include <iostream.h>
#include <math.h>

// encoder  - defines the code being used
// state    - the state we're starting from at this node
// wt       - the weight of considered codeword up to this node
// left     - the number of symbols left to consider
// count    - a global table holding the number of codewords for each length
// w_max    - the largest weight codeword considered
// tail     - a global table with weights of tails associated with each node
void followpath(fsm& encoder, const int state, const int wt, const int left, int *count, const int w_max, const int *tail)
   {
   const int ninputs = encoder.num_inputs();
   for(int i=0; i<ninputs; i++)
      {
      encoder.reset(state);
      int new_wt = weight(encoder.step(i)) + wt;
      int new_state = encoder.state();
      if(left == 1)
         {
         new_wt += tail[new_state];
         if(new_wt <= w_max)
            count[new_wt]++;
         }
      else if(new_wt <= w_max)
         followpath(encoder, new_state, new_wt, left-1, count, w_max, tail);
      }
   }

int main(int argc, char *argv[])
   {
   timer tim_main("Main timer");

   // Encoder (from generator matrix)
   const int k=1, n=2, m=2;
   matrix<bitfield> gen(k, n);
   gen(0, 0) = "111";
   gen(0, 1) = "101";
   rscc encoder(k, n, gen);
   // block size
   const int tau = argc>2 ? atoi(argv[2])+m : 32+m;
   // results array
   const int w_max = argc>1 ? atoi(argv[1]) : 10;
   int count[w_max+1];

   // initialise results array
   for(int w=1; w<=w_max; w++)
      count[w] = 0;

   // work out weights associated with tails
   const int nstates = 1<<m;
   int tail[nstates];
   for(int s=0; s<nstates; s++)
      {
      tail[s] = 0;
      encoder.reset(s);
      for(int i=0; i<m; i++)
         {
         int input = fsm::tail;
         int output = encoder.step(input);
         tail[s] += weight(output);
         }
      }

   // do it
   followpath(encoder, 0, 0, tau-m, count, w_max, tail);
      
   // print results
   cout << "# Chosen code:\n";
   cout << "# (" << n*tau << ", " << k*(tau-n) << ") block\n";
   cout << "# recursive convolutional code (k=" << k << ", n=" << n << ")\n";
   cout << "# generator matrix:\n";
   for(int i=0; i<n; i++)
      {
      cout << "#";
      for(int j=0; j<k; j++)
         cout << "\t" << gen(j,i);
      cout << "\n";
      }

   // weight spectrum
   cout << "\n# Weight Spectrum:\n";
   cout << "# w\tAw\n";
   for(int w=1; w<=w_max; w++)
      cout << "# " << w << "\t" << count[w] << "\n";

   // work the union bound for a BPSK/AWGN system
   cout << "\n# Union Bound:\n";
   for(double snr_db=0; snr_db<=8; snr_db+=1)
      {
      double snr = pow(10, snr_db/10.0);
      double r = double(k*(tau-m))/double(n*tau);
      double bound = 0;
      for(int w=1; w<=w_max; w++)
         bound += count[w] * Q(sqrt(2*snr*r*w));
      cout << snr_db << "\t" << bound << "\n";
      }
   }
