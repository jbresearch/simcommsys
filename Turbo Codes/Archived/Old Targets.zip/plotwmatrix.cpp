#include "bpsk.h"
#include "awgn.h"
#include "logreal.h"

#include "puncture_null.h"

#include "map.h"
#include "turbo.h"

#include "matrix.h"
#include "vector.h"
#include "timer.h"
#include "itfunc.h"

#include "arguments.h"

#include <iostream.h>
#include <math.h>

int cw_weight(vector<int>& encoded, const int tau)
   {
   int w = 0;
   for(int t=0; t<tau; t++)
      w += weight(encoded(t));
   return w;
   }

void update(int *pos, const int start, const int end)
   {
   pos[start]++;
   if(start == end-1)
      return;
   if(pos[start+1] == pos[start])
      {
      pos[start] = start;
      update(pos, start+1, end);
      }
   }

int main(int argc, char *argv[])
   {
   timer tim_main("Main timer");

   // Read User Parameters
   arguments userargs(argc, argv);
   arguments_interleaver inter;
   userargs.add_processor(&inter);
   arguments_i iw;
   userargs.add_processor(&iw);
   userargs.process();

   // Analysis parameters
   // i_min/i_max = range of information weight considered
   const int i_min = iw.get_min();
   const int i_max = iw.get_max();
   if(i_min < 1 || i_max < i_min)
      {
      cerr << "Invalid range of input weight (" << i_min << ", " << i_max << ")\n";
      exit(1);
      }
   // Codec parameters
   const bool simile = inter.get_simile();
   const bool endatzero = inter.get_endatzero();
   const int tau = inter.get_tau();
   const int m = endatzero ? inter.get_m() : 0;
   const int n = inter.get_n();
   const int k = inter.get_k();
   // Puncturing system
   puncture_null punc(tau, 3);

   // source and encoded messages
   vector<int> source(tau), encoded(tau);
   // encoder
   bpsk modem;
   awgn chan;
   turbo<logreal> codec(*inter.get_encoder(), modem, punc, chan, tau, inter.get_vinter(), 1, simile, endatzero);

   // N = bits/codeword
   // K = information bits/codeword
   const int N = tau*(2*n-k);
   const int K = (tau-m)*k;
   // zero entry unused
   vector<int> count(i_max+1);
   matrix<int> A(i_max+1, N+1);

   // initialise results array
   for(int i=i_min; i<=i_max; i++)
      {
      count(i) = 0;
      for(int w=1; w<=N; w++)
         A(i,w) = 0;
      }

   // weight spectrum
   cout << "#\n# Weight Spectrum:\n";
   cout << "# i";
   for(int w=1; w<=N; w++)
      cout << "\tA(i," << w << ")";
   cout << "\n" << flush;

   for(int i=i_min; i<=i_max; i++)
      {
      cerr << "\rProfiling information weight " << i;
      int pos[i];
      // initialise positions for 1's
      for(int j=0; j<i; j++)
         pos[j] = j;
      // cycle through all combinations for this information weight
      do {
         // initialise data block to all-zeros
         for(int t=0; t<tau-m; t++)
            source(t) = 0;
         // initialise tail bits
         for(int t=tau-m; t<tau; t++)
            source(t) = fsm::tail;
         // set bits that are 1
         for(int j=0; j<i; j++)
            source(pos[j]) = 1;
         // encode the source frame
         codec.encode(source, encoded);
         // calculate weight for the associated codeword
         int wt = cw_weight(encoded, tau);
         A(i,wt)++;
         // update position for 1's for next cycle
         update(pos, 0, i);
         // update count of tested codewords at this weight
         count(i)++;
         } while(pos[i-1] < tau-m);
      cout << "# " << i;
      for(int w=1; w<=N; w++)
         cout << "\t" << A(i,w);
      cout << "\n" << flush;
      }
   cerr << "\n" << flush;

   // work the bounds for a BPSK/AWGN system
   cout << "#\n# Modified Union Bound:\n";
   cout << "# SNR";
   for(int i=i_min; i<=i_max; i++)
      cout << "\tPr(" << i << ")";
   cout << "\n" << flush;

   for(double snr_db=0; snr_db<=8; snr_db+=1)
      {
      double snr = pow(10, snr_db/10.0);
      double R = double(K)/double(N);

      double bound = 0;
      cout << snr_db;
      for(int w=1; w<=N; w++)
         {
         for(int i=i_min; i<=i_max; i++)
            bound += A(i,w) * i/K * Q(sqrt(2*w*R*snr));
         if(bound > 0)
            cout << "\t" << bound;
         }
      cout << "\n" << flush;
      }
   }
