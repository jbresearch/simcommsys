#include "map.h"
#include "turbo.h"
#include "uncoded.h"

#include "mpgnu.h"
#include "rscc.h"

#include "helical.h"
#include "file_lut.h"
#include "shift_lut.h"
#include "padded.h"

#include "puncture_stipple.h"

#include "bpsk.h"
#include "awgn.h"
#include "randgen.h"
#include "commsys_profiler.h"
#include "montecarlo.h"
#include "timer.h"
#include "cmpi.h"

#include <iostream.h>
#include <math.h>


int main(int argc, char *argv[])
   {
   timer tim_main("Main timer");
   
   // Simulation parameters
   const double SNRmin = 0, SNRmax = 4, SNRstep = 1;
   const double BERmin = 1e-3;
   const double accuracy = 0.1;
   const double confidence = 0.95;
   const int bailout = 100;
   
   // Encoder (from generator matrix)
   const int k=1, n=2, m=2;
   matrix<bitfield> gen(k, n);
   gen(0, 0) = "111";
   gen(0, 1) = "101";
   rscc encoder(k, n, gen);
   // Helical Interleaver (from matrix size, hence block size)
   const int rows = 17, cols = 6;
   const int tau = rows*cols + m;
   helical inter(tau, rows, cols);
//   const int p = (1<<m)-1;
//   shift_lut interh(2*p, tau);
//   padded inter(interh, encoder, tau);
//   file_lut inter(argv[1], tau);
   vector<interleaver *> vinter(1);
   vinter(0) = &inter;
   // Modulation scheme
   bpsk modem;
   // Channel Model
   awgn chan;
   // Puncturing system
   puncture_stipple punc(tau, 3);
   // Channel Codec
//   map<mpgnu> codec(encoder, modem, chan, tau);
   turbo<mpgnu> codec(encoder, modem, punc, chan, tau, vinter, 5, true, true);
   // Source Generator
   randgen src;
   // The complete communication system
   commsys_profiler system(&src, &chan, &codec);

   // The actual estimator
   montecarlo estimator(&system);
   estimator.set_confidence(confidence);
   estimator.set_accuracy(accuracy);
   estimator.set_bailout(bailout);
   
   // Initialise MPI
   cmpi::enable(&argc, &argv);

   // Work out the following for every SNR value required
   double BER = 1;
   for(double SNR = SNRmin; SNR <= SNRmax && BER > BERmin; SNR += SNRstep)
      {
      chan.set_snr(SNR);

      cerr << "Simulating system at Eb/No = " << SNR << "\n";
      vector<double> estimate, tolerance;
      estimator.estimate(estimate, tolerance);
      
      cout << SNR;
      for(int i=0; i<system.count(); i++)
         cout << "\t" << estimate(i) << "\t" << estimate(i)*tolerance(i);
      cout << "\n";
      }
   
   return 0;
   }

