#include <iostream.h>
#include "vector.h"
#include "randgen.h"

/*
   Version 1.00
   Randomisation is performed by initialising a sequential LUT and performing a large number
   of random swaps (100*tau swaps).

   Version 2.00 (25 May 1999)
   Randomisation is performed as it is supposed to be (ie. by randomly selecting a match, and
   checking if it already was used). Random selections have a flat distribution profile.
*/
int main(int argc, char *argv[])
   {
   if(argc < 2)
      {
      cerr << "Usage: " << argv[0] << " <tau> [<seed>]\n";
      exit(1);
      }

   const int tau = atoi(argv[1]);

   // create LUT
   vector<int> lut;
   lut.init(tau);
   // create and initialise random generator
   randgen r;
   r.seed(argc > 2 ? atoi(argv[2]) : 0);

   // create array to hold 'used' status of possible lut values
   bool used[tau];
   for(int t=0; t<tau; t++)
      used[t] = false;
   // fill in lut
   for(int t=0; t<tau; t++)
      {
      int tdash;
      do {
         tdash = r.ival(tau);
         } while(used[tdash]);
      used[tdash] = true;
      lut(t) = tdash;
      }

   for(int i=0; i<tau; i++)
      cout << i << "\t" << lut(i) << "\n";
   }
