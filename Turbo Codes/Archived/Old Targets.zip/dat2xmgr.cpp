#include "vector.h"
#include "matrix.h"

#include <iostream.h>
#include <string.h>
#include <time.h>

int main()
   {
   // data for subsequent plotting
   int xcntmax=40, xcnt=0, ycnt=0;
   vector<double> snr;
   matrix<double> ber, fer, bertol, fertol;
   double tolerance=0, confidence=0;
   char *date = new char[64];
   char *codec = new char[512];
   char *codec2 = new char[512];

   // line buffer for parsing input file
   const int bufsize = 65536;
   char buf[bufsize];
   // read the data (including information)
   for(int line=0; cin.get(buf, bufsize, '\n'); line++)
      {
      // check that the buffer was not exceeded
      char c;
      if(cin.get(c) && c != '\n')
         {
         cerr << "Buffer exceeded at line " << line << "\n";
         exit(1);
         }
      // if this is an INFO line, read the required data
      if(strncmp(buf, "#%", 2) == 0)
         {
         // find the delimiter
         char *del = strchr(buf, ':');
         if(del == NULL)
            {
            cerr << "Cannot find delimeter in line (" << buf << ")\n";
            exit(1);
            }
         // prepare two strings - the name of the information, and its value
         char *name = buf+3;
         del[0] = '\0';
         char *value = del+2;
         // now check what the information is, and do something about it
         if(strcmp(name, "Tolerance") == 0)
            tolerance = atof(value);
         else if(strcmp(name, "Confidence") == 0)
            confidence = atof(value);
         else if(strcmp(name, "Date") == 0)
            strcpy(date, value);
         else if(strcmp(name, "Codec") == 0)
            strcpy(codec, value);
         else if(strcmp(name, "Codec2") == 0)
            strcpy(codec2, value);
         else
            cerr << "Don't know how to process INFO type (" << name << ")\n";
         }
      // otherwise (unless it is a plain comment) read the data
      else if(buf[0] != '#')
         {
         // check if xcnt has exceeded its maximum
         if(xcnt >= xcntmax)
            {
            cerr << "Number of x-points exceeded.\n";
            exit(1);
            }
         // if we don't know ycnt, get it from this line
         if(ycnt == 0)
            {
            char *s = buf;
            do {
               strtod(s, &s);
               ycnt++;
               } while(s != NULL && s[0] != '\0');
            ycnt = (ycnt-1)/4;
            // once we know ycnt, allocate the buffers
            snr.init(xcntmax);
            ber.init(xcntmax, ycnt);
            fer.init(xcntmax, ycnt);
            bertol.init(xcntmax, ycnt);
            fertol.init(xcntmax, ycnt);
            }
         // Read the line into the appropriate buffer
         char *s = buf;
         snr(xcnt) = strtod(s, &s);
         for(int y=0; y<ycnt; y++)
            {
            ber(xcnt, y) = strtod(s, &s);
            bertol(xcnt, y) = strtod(s, &s);
            fer(xcnt, y) = strtod(s, &s);
            fertol(xcnt, y) = strtod(s, &s);
            }
         xcnt++;
         }
      }

   // work out the limits for the graph
   double xmin = snr(0);
   double xmax = snr(xcnt-1);

   // write back in appropriate form
   cout << "@title size 1.00\n";
   cout << "@subtitle size 0.75\n";
   cout << "@title \"" << codec << " simulation (�" << tolerance << "% at " << confidence << "%), " << date << "\"\n";
   cout << "@subtitle \"" << codec2 << "\"\n";
   for(int g=0; g<2; g++)
      {
      cout << "@with g" << g << "\n";
      cout << "@g" << g << " on\n";
      cout << "@g" << g << " type logy\n";
      cout << "@g" << g << " autoscale type auto\n";
      cout << "@view xmin " << 0.1 << "\n";
      cout << "@view xmax " << 0.9 << "\n";
      cout << "@view ymin " << (g==0 ? 0.525 : 0.1) << "\n";
      cout << "@view ymax " << (g==0 ? 0.9 : 0.475) << "\n";
      cout << "@world xmin " << xmin << "\n";
      cout << "@world xmax " << xmax << "\n";
      cout << "@world ymin " << (g==0 ? 1e-5 : 1e-3) << "\n";
      cout << "@world ymax " << (g==0 ? 0.5 : 1.0) << "\n";
      cout << "@legend on\n";
      cout << "@legend char size 0.60\n";
      cout << "@legend x1 0.115\n";
      cout << "@legend y1 " << (g==0 ? 0.9 : 0.475) - 0.015 << "\n";
      cout << "@xaxis tick major 1\n";
      cout << "@xaxis tick minor 0.5\n";
      cout << "@yaxis tick major 1\n";
      cout << "@yaxis tick minor 1\n";
      cout << "@xaxis tick major grid on\n";
      cout << "@xaxis tick minor grid on\n";
      cout << "@yaxis tick major grid on\n";
      cout << "@yaxis tick minor grid on\n";
      cout << "@xaxis tick major linestyle 2\n";
      cout << "@xaxis tick minor linestyle 2\n";
      cout << "@yaxis tick major linestyle 2\n";
      cout << "@yaxis tick minor linestyle 2\n";
      cout << "@xaxis ticklabel format decimal\n";
      cout << "@xaxis ticklabel prec 1\n";
      cout << "@xaxis label \"Eb/No (dB)\"\n";
      cout << "@yaxis ticklabel format power\n";
      cout << "@yaxis ticklabel prec 0\n";
      cout << "@yaxis label \"" << (g==0 ? "BER" : "FER") << "\"\n";
      if(g==0)
         {
         cout << "@xaxis ticklabel color 0\n";
         cout << "@xaxis label color 0\n";
         }
      for(int y=0; y<ycnt; y++)
         {
         cout << "@s" << y << " on\n";
         cout << "@s" << y << " color 1\n";
         cout << "@legend string " << y << " \"" << y+1 << (y==0 ? " iteration\"\n" : " iterations\"\n");
         cout << "@type xydy\n";
         for(int x=0; x<xcnt; x++)
            if(g == 0)
               cout << snr(x) << "\t" << ber(x,y) << "\t" << bertol(x,y) << "\n";
            else
               cout << snr(x) << "\t" << fer(x,y) << "\t" << fertol(x,y) << "\n";
         cout << "&\n";
         }
      }
   }
