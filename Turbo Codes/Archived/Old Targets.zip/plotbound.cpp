#include <iostream.h>
#include <stdio.h>
#include <stdlib.h>

#include "itfunc.h"
#include "timer.h"

inline int multiplicity(int tau, int len, int n)
   {
   return combinations(tau-len+n, n);
   }

int main(int argc, char *argv[])
   {
   // Get user parameters
   if(argc < 7)
      {
      cerr << "Usage: " << argv[0] << " <irwef.file> <tau> <R> <SNRmin> <SNRmax> <SNRstep>\n";
      exit(1);
      }
   // Check parameters
   const double R = atof(argv[3]);
   const double SNRmin = atof(argv[4]);
   const double SNRmax = atof(argv[5]);
   const double SNRstep = atof(argv[6]);
   if(SNRmax < SNRmin || SNRstep <= 0)
      {
      cerr << "Invalid SNR parameters: " << SNRmin << ", " << SNRmax << ", " << SNRstep << "\n";
      exit(1);
      }
   // First we read the table of error events from file
   int tau = atoi(argv[2]);
   FILE *file = fopen(argv[1], "rb");
   if(file == NULL)
      {
      cerr << "Cannot open input file <" << argv[1] << ">\n";
      exit(1);
      }
   // get the size of the required matrix
   int wmax = 0;
   while(!feof(file))
      {
      int iw, ow, a;
      while(fscanf(file, "%d%d%d", &iw, &ow, &a) == 0)
         fscanf(file, "%*[^\n]\n");
      if(!feof(file))
         if(iw>wmax)
            wmax = iw;
      }
   // now read the matrix
   int A[wmax+1][wmax+1];
   rewind(file);
   for(int i=0; i<wmax*wmax; i++)
      {
      int iw, ow, a;
      while(fscanf(file, "%d%d%d", &iw, &ow, &a) == 0)
         fscanf(file, "%*[^\n]\n");
      A[iw][ow] = a;
      }
   fclose(file);
   cerr << "Read input: wmax = " << wmax << ", tau = " << tau << "\n";

   // finally plot the required results
   for(double SNR = SNRmin; SNR <= SNRmax; SNR += SNRstep)
      {
      double snr = pow(10.0, SNR/10.0);
      double Pb = 0;
      cout << SNR << "\t";
      for(int ow=1; ow<=wmax; ow++)
         {
         for(int iw=1; iw<=wmax; iw++)
            Pb += A[iw][ow] * iw/tau * Q(sqrt(2*ow*R*snr));
         if(Pb > 0)
            cout << Pb << "\t";
         }
      cout << "\n";
      }
   }
