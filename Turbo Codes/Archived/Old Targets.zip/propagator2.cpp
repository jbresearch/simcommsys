#include "bcjr.h"

#include "mpgnu.h"
#include "nrcc.h"

#include "bpsk.h"
#include "awgn.h"
#include "randgen.h"

#include "vector.h"

#include <iostream.h>
#include <math.h>


int main(int argc, char *argv[])
   {
   // Encoder (from generator matrix)
   const int k=1, n=2, m=2;
   matrix<bitfield> gen(k, n);
   gen(0, 0) = "111";
   gen(0, 1) = "101";
   nrcc encoder(k, n, gen);
   // Other constants
   const int tau = 100;
   const int K = 1<<k;
   const int N = 1<<n;
   // Modulation scheme
   bpsk modem;
   // Channel Model
   awgn chan;
   // Channel Codec
   bcjr<mpgnu> decoder(encoder, tau);
   // Source Generator
   randgen src;

   // Create a random source
   vector<int> source(tau);
   for(int t=0; t<tau-m; t++)
      source(t) = src.ival(K);
   for(int t=tau-m; t<tau; t++)
      source(t) = fsm::tail;

   // Encode it
   vector<int> encoded(tau);
   encoder.reset(0);
   for(int t=0; t<tau; t++)
      encoded(t) = encoder.step(source(t));

   // Modulate it
   matrix<sigspace> tx(tau, n);
   for(int t=0; t<tau; t++)
      for(int i=0; i<n; i++)
         tx(t, i) = modem[(encoded(t) >> i) & 1];

   // Introduce hard errors
   const int cnt = argc>1 ? atoi(argv[1])+1 : 1;
   for(int j=1; j<cnt; j++)
      for(int i=0; i<n; i++)
         tx(j*tau/cnt, i) = modem[((encoded(j*tau/cnt) >> i) & 1) ^ 1];

   // Assuming a value for SNR, calculate the a-priori statistics
   chan.set_snr(0);
   matrix<double> R(tau, N);
   for(int t=0; t<tau; t++)
      for(int x=0; x<N; x++)
         {
         R(t, x) = 1;
         if(t != tau/2)
            for(int i=0; i<n; i++)
               R(t, x) *= chan.pdf(modem[(x>>i) & 1], tx(t, i));
         else
            for(int i=k; i<n; i++)
               R(t, x) *= chan.pdf(modem[(x>>i) & 1], tx(t, i));
         }

   // Decode using the BCJR algorithm
   matrix<double> ri(tau, K), ro(tau, N);
   decoder.decode(R, ri, ro);

   // Output some statistics to plot
   for(int t=0; t<tau; t++)
      {
      cout << t << "\t";
      double app = ri(t, source(t))/ri(t, source(t)^1);
      cout << app << "\n";
      }

   return 0;
   }

