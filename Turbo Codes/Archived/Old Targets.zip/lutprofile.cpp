#include "arguments.h"

#include "vector.h"
#include <iostream.h>
#include <math.h>
#include <stdlib.h>

void plot_profile(vector<int>& lut, const int maxdist)
   {
   const int tau = lut.size();
   for(int i=0; i<tau; i++)
      for(int j=i+1; j<min(tau,i+maxdist); j++)
         {
         int d = int(fabs(lut(j)-lut(i)));
         if(d <= maxdist)
            cout << (j-i) << "\t" << d << "\n";
         }
   }

int main(int argc, char *argv[])
   {
   // Read User Parameters
   arguments userargs(argc, argv);
   arguments_interleaver inter;
   userargs.add_processor(&inter);
   userargs.process();

   // Interleaver parameters
   const int tau = inter.get_tau();

   // Limit the analysis to a certain distance
   const int maxdist = min(100,tau);
   
   // Generate LUT from the interleaver
   vector<int> in(tau), out(tau);
   for(int i=0; i<tau; i++)
      in(i) = i;
   inter.get_inter()->transform(in, out);

   // Print the mapping
   for(int i=0; i<tau; i++)
      cout << "# " << i << "\t" << out(i) << "\n";

   // Plot the required profile
   plot_profile(out, maxdist);

   return 0;
   }
