#include "annealer.h"
#include "anneal_puncturing.h"

int main(int argc, char *argv[])
   {
   if(argc < 4)
      {
      cerr << "Usage: " << argv[0] << " <filename> <tau> <s>\n";
      exit(1);
      }

   const int tau = atoi(argv[2]);
   const int s = atoi(argv[3]);

   anneal_puncturing system(argv[1], tau, s);
   annealer optimiser(system);

   const double E = system.energy();
   cerr << "Starting energy = " << E << "\n";
   optimiser.set_temperature(E, E*1E-9);
   optimiser.set_iterations(1000*tau, 100*tau);
   optimiser.improve();
   cerr << "Ending energy = " << system.energy() << "\n";

   return 0;
   }
