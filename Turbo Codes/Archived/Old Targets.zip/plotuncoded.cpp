#include <iostream.h>
#include <math.h>

#include "timer.h"
#include "arguments.h"
#include "itfunc.h"

int main(int argc, char *argv[])
   {
   timer tim_main("Main timer");
   
   // Read User Parameters
   arguments userargs(argc, argv);
   arguments_snr snr;
   userargs.add_processor(&snr);
   userargs.process();

   // Check parameters
   const double SNRmax = snr.get_max();
   const double SNRmin = snr.get_min();
   const double SNRstep = snr.get_step();
   if(SNRmax < SNRmin || SNRstep <= 0)
      {
      cerr << "Invalid SNR parameters: " << SNRmin << ", " << SNRmax << ", " << SNRstep << "\n";
      exit(1);
      }
   
   // Print information on the results being worked
   cout << "#% Date: " << timer::date() << "\n";
      
   // Work out the following for every SNR value required
   for(double SNR = SNRmin; SNR <= SNRmax; SNR += SNRstep)
      {
      double snr = pow(10.0, SNR/10.0);
      double Pb = Q(sqrt(2*snr));
      cout << SNR << "\t" << Pb << "\n";
      }

   return 0;

   }
