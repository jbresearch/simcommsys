#include "annealer.h"
#include "anneal_interleaver.h"

int main(int argc, char *argv[])
   {
   if(argc < 7)
      {
      cerr << "Usage: " << argv[0] << " <sets> <tau> <m> <type> <term> <seed>\n";
      exit(1);
      }

   const int sets = atoi(argv[1]);
   const int tau = atoi(argv[2]);
   const int m = atoi(argv[3]);
   const int type = atoi(argv[4]);
   const bool term = atoi(argv[5]);
   const int seed = atoi(argv[6]);

   anneal_interleaver system(sets, tau, m, type, term, seed);
   annealer optimiser(system);

   const double E = system.energy();
   optimiser.set_temperature(E, E*1E-8);
   //optimiser.set_iterations(100*tau, 10*tau);
   optimiser.set_iterations(10*tau, 1*tau);

   optimiser.improve();

   return 0;
   }
