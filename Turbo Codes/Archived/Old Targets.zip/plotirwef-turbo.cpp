#include <iostream.h>
#include <stdio.h>
#include <stdlib.h>

#include "itfunc.h"
#include "timer.h"

inline int multiplicity(int tau, int len, int n)
   {
   return combinations(tau-len+n, n);
   }

int main(int argc, char *argv[])
   {
   // First we read the table of error events from file
   if(argc < 3)
      {
      cerr << "Usage: " << argv[0] << " <irwef.file> <tau>\n";
      exit(1);
      }
   int tau = atoi(argv[2]);
   FILE *file = fopen(argv[1], "rb");
   if(file == NULL)
      {
      cerr << "Cannot open input file <" << argv[1] << ">\n";
      exit(1);
      }
   // get the size of the required matrix
   int rows = 0, wmax = 0;
   while(!feof(file))
      {
      int iw, ow;
      double a;
      while(fscanf(file, "%d%d%lf", &iw, &ow, &a) == 0)
         fscanf(file, "%*[^\n]\n");
      if(!feof(file))
         rows++;
      if(wmax < iw)
         wmax = iw;
      if(wmax < ow)
         wmax = ow;
      }
   // now create the multiplicity matrix
   double A[wmax][wmax];
   for(int i=0; i<wmax; i++)
      for(int j=0; j<wmax; j++)
         A[i][j] = 0;
   // and read it from file
   rewind(file);
   for(int i=0; i<rows; i++)
      {
      int iw, ow;
      double a;
      while(fscanf(file, "%d%d%lf", &iw, &ow, &a) == 0)
         fscanf(file, "%*[^\n]\n");
      A[iw-1][ow-1] = a;
      }
   fclose(file);
   cerr << "Read input: " << rows << " entries, wmax = " << wmax << ", tau = " << tau << "\n";

   // Now we want to work out the IRWEF for the Turbo code with a uniform interleaver.
   // So we start by creating the results matrix.
   double B[wmax][wmax];
   for(int i=0; i<wmax; i++)
      for(int j=0; j<wmax; j++)
         B[i][j] = 0;
   // next we consider all combinations of component codes with the same input weight.
   for(int iw=1; iw<=wmax; iw++)
      for(int ow1=iw; ow1<=wmax; ow1++)
         for(int ow2=iw; ow2<=wmax; ow2++)
            {
            // note that this TC weight computation ignores the tail effects
            int r1 = ow1 - iw;
            int r2 = ow2 - iw;
            int ow = iw + r1 + r2;
            if(ow <= wmax)
               B[iw-1][ow-1] += A[iw-1][ow1-1] * A[iw-1][ow2-1];
            }
      
   // finally print the acquired results
   // first print a table of ow, B(ow)
   for(int j=0; j<wmax; j++)
      {
      cout << "# " << j+1;
      double a = 0;
      for(int i=0; i<wmax; i++)
         a += B[i][j];
      cout << "\t" << a << "\n";
      }
   // then print a table of iw, ow, B(iw,ow)
   for(int i=0; i<wmax; i++)
      for(int j=0; j<wmax; j++)
         cout << i+1 << "\t" << j+1 << "\t" << B[i][j] << "\n";
   }
