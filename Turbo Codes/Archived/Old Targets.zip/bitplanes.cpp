#include "picture.h"
#include "randgen.h"
#include <iostream.h>
#include <math.h>

int main(int argc, char *argv[])
   {
   if(argc < 4)
      {
      cerr << "Usage: " << argv[0] << " <infile> <outfile> <plane>\n";
      exit(1);
      }
   
   picture p;

   cerr << "Loading from file (" << argv[1] << ")\n";
   p.load(argv[1]);

   cerr << "Processing\n";
   const int plane = atoi(argv[3]);
   cerr << "Extracting lower " << plane << " plane(s)\n";
   for(int x=0; x<p.width(); x++)
      for(int y=0; y<p.height(); y++)
         {
         const int r = (p(x,y).red()   << 8-plane) & 0xff;
         const int g = (p(x,y).green() << 8-plane) & 0xff;
         const int b = (p(x,y).blue()  << 8-plane) & 0xff;
         p(x,y) = pixel(r, g, b);
         }

   cerr << "Saving to file (" << argv[2] << ")\n";
   p.save(argv[2]);

   return 0;
   }
