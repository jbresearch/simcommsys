#include "randgen.h"
#include "timer.h"
#include <iostream.h>

int main()
   {
   timer t("Main Timer");
   randgen r;

   for(int i=0; ; i++)
      {
      const double f = r.fval();
      if(f == 1.0)
         cerr << "1.0 found at i = " << i << " (" << t << ")\n" << flush;
      if(f == 0.0)
         cerr << "0.0 found at i = " << i << " (" << t << ")\n" << flush;
      if(i % int(1E7) == 0)
         cerr << "tested " << i << " random numbers\r" << flush;
      }
   }

