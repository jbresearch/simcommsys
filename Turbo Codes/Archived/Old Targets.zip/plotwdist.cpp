#include "rscc.h"
#include "bpsk.h"
#include "awgn.h"
#include "logreal.h"

#include "map.h"

#include "puncture_stipple.h"

#include "turbo.h"
#include "vale96int.h"
#include "helical.h"
#include "file_lut.h"
#include "shift_lut.h"
#include "padded.h"

#include "matrix.h"
#include "vector.h"
#include "timer.h"
#include "itfunc.h"

#include <iostream.h>
#include <math.h>

int cw_weight(vector<int>& encoded, const int tau)
   {
   int w = 0;
   for(int t=0; t<tau; t++)
      w += weight(encoded(t));
   return w;
   }

void update(int *pos, const int i, const int w)
   {
   pos[i]++;
   if(i == w-1)
      return;
   if(pos[i+1] == pos[i])
      {
      pos[i] = i;
      update(pos, i+1, w);
      }
   }

int main(int argc, char *argv[])
   {
   timer tim_main("Main timer");

   // Encoder (from generator matrix)
   const int k=1, n=2, m=2;
   matrix<bitfield> gen(k, n);
   gen(0, 0) = "111";
   gen(0, 1) = "101";
   rscc encoder(k, n, gen);
   // Matt Valenti's Interleaver (fixed size)
   const int tau = 34;
   vale96int inter;
   vector<interleaver *> vinter(1);
   vinter(0) = &inter;
   // source and encoded messages
   vector<int> source(tau), encoded(tau);
   // Puncturing system
   puncture_stipple punc(tau, 3);
   // encoder
   bpsk modem;
   awgn chan;
   turbo<logreal> codec(encoder, modem, punc, chan, tau, vinter, 1, false, true);
//   map<logreal> codec(encoder, modem, chan, tau);
   // results array
   const int w_max = argc>1 ? atoi(argv[1]) : 10;
   int count[w_max+1], total[w_max+1];

   // initialise results array
   for(int w=1; w<=w_max; w++)
      count[w] = total[w] = 0;

   // weight spectrum
   cout << "#\n# Weight Spectrum:\n";
   cout << "# w\tAw\n";
   for(int w=1; w<=w_max; w++)
      {
      int pos[w];
      // initialise positions for 1's
      for(int i=0; i<w; i++)
         pos[i] = i;
      // cycle through all combinations for this weight
      do {
         // initialise data block to all-zeros
         for(int t=0; t<tau-m; t++)
            source(t) = 0;
         // initialise tail bits
         for(int t=tau-m; t<tau; t++)
            source(t) = fsm::tail;
         // set bits that are 1
         for(int i=0; i<w; i++)
            source(pos[i]) = 1;
         // encode the source frame
         codec.encode(source, encoded);
         // calculate weight for the associated codeword
         int wt = cw_weight(encoded, tau);
         if(wt <= w_max)
            count[wt]++;
         // update position for 1's for next cycle
         update(pos, 0, w);
         // update count of tested codewords at this weight
         total[w]++;
         } while(pos[w-1] < tau-m);
      cout << "# " << w << "\t" << count[w] << "\t" << total[w] << "\n" << flush;
      }

   // work the union bound for a BPSK/AWGN system
   cout << "#\n# Union Bound:\n";
   for(double snr_db=0; snr_db<=8; snr_db+=1)
      {
      double snr = pow(10, snr_db/10.0);
      double r = double(k*(tau-m))/double(n*tau);
      double bound = 0;
      for(int w=1; w<=w_max; w++)
         bound += count[w] * Q(sqrt(2*snr*r*w));
      cout << snr_db << "\t" << bound << "\n";
      }

   return 0;
   }
