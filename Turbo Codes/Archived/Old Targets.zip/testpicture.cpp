#include "picture.h"
#include "randgen.h"
#include <iostream.h>
#include <math.h>

int main(int argc, char *argv[])
   {
   if(argc < 6)
      {
      cerr << "Usage: " << argv[0] << " <infile> <outfile> <snr> <length> <dim>\n";
      exit(1);
      }
   
   picture p;

   cerr << "Loading from file (" << argv[1] << ")\n";
   p.load(argv[1]);

   cerr << "Processing\n";
   const double snr = atof(argv[3]);
   const int len = atoi(argv[4]);
   const int dim = atoi(argv[5]);

   const double sigma = pow(10, snr/20.0) / sqrt(dim);

   randgen r[dim];
   for(int i=0; i<dim; i++)
      r[i].seed(i);

   for(int x=0; x<p.width(); x++)
      for(int y=0; y<p.height(); y++)
         {
         double g = 0;
         for(int i=0; i<dim; i++)
            g += r[i].gval(sigma);
         p(x,y) += pixel(g);
         }

   p.quantise(8);

   for(int i=0; i<dim; i++)
      r[i].seed(i);

   double sum[dim], ms[dim], msq[dim];
   for(int i=0; i<dim; i++)
      sum[i] = ms[i] = msq[i] = 0;

   int cnt = 0, n = 0;
   for(int x=0; x<p.width(); x++)
      for(int y=0; y<p.height(); y++)
         {
         for(int i=0; i<dim; i++)
            sum[i] += p(x,y).luminance() * r[i].gval(1.0);
         cnt++;
         if(cnt == len)
            {
            for(int i=0; i<dim; i++)
               {
               sum[i] /= len * sigma * sqrt(dim);
               ms[i] += sum[i];
               msq[i] += sum[i]*sum[i];
               sum[i] = 0;
               }
            cnt = 0;
            n++;
            }
         }

   cerr << "n = " << n << "\n";
   cerr << "sigma = " << sigma << "\n";
   for(int i=0; i<dim; i++)
      {
      double mean = ms[i]/n;
      double var = msq[i]/n - mean*mean;
      double sd = sqrt(var);
      cerr << "i = " << i << "\t";
      cerr << "mean = " << mean << "\t";
      cerr << "sd = " << sd << "\t";
      double EbNo = -10*log10(2*var*1/3);
      cerr << "EbNo (1/3) = " << EbNo << "\t";
      EbNo = -10*log10(2*var*1/5);
      cerr << "EbNo (1/5) = " << EbNo << "\n";
      }

   cerr << "Saving to file (" << argv[2] << ")\n";
   p.save(argv[2]);

   return 0;
   }
