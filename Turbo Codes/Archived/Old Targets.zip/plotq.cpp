#include <iostream.h>
#include <math.h>

#include "timer.h"
#include "arguments.h"
#include "itfunc.h"

int main(int argc, char *argv[])
   {
   timer tim_main("Main timer");
   
   // Read User Parameters
   arguments userargs(argc, argv);
   arguments_snr snr;
   userargs.add_processor(&snr);
   arguments_i iw;
   userargs.add_processor(&iw);
   arguments_rate rate;
   userargs.add_processor(&rate);
   userargs.process();

   // Check parameters
   const double SNRmax = snr.get_max();
   const double SNRmin = snr.get_min();
   const double SNRstep = snr.get_step();
   if(SNRmax < SNRmin || SNRstep <= 0)
      {
      cerr << "Invalid SNR parameters: " << SNRmin << ", " << SNRmax << ", " << SNRstep << "\n";
      exit(1);
      }
   const double R = rate.get_rate();
   if(R <= 0)
      {
      cerr << "Invalid code rate: " << R << "\n";
      exit(1);
      }
   const int i_max = iw.get_max();
   const int i_min = iw.get_min();
   if(i_max < i_min)
      {
      cerr << "Invalid weight range parameters: " << i_min << ", " << i_max << "\n";
      exit(1);
      }

   // Print information on the results being worked
   cout << "#% Rate: " << R << "\n";
   cout << "#% SNR: " << SNRmin << ":" << SNRstep << ":" << SNRmax << "\n";
   cout << "#% Weight: " << i_min << ":" << i_max << "\n";
   cout << "#% Date: " << timer::date() << "\n";
      
   // Work out the following for every SNR value required
   for(int i=i_min; i<=i_max; i++)
      {
      cout << i;
      for(double SNR = SNRmin; SNR <= SNRmax; SNR += SNRstep)
         {
         double snr = pow(10.0, SNR/10.0);
         double Pb = Q(sqrt(2*i*R*snr));
         cout << "\t" << Pb;
         }
      cout << "\n";
      }

   return 0;
   }
