#include "turbo.h"

#include "logreal.h"
#include "mpgnu.h"

#include "bpsk.h"
#include "awgn.h"
#include "randgen.h"
#include "commsys.h"
#include "montecarlo.h"
#include "timer.h"
#include "cmpi.h"
#include "arguments.h"
#include "vector.h"

#include <iostream.h>
#include <math.h>
#include <string.h>


int main(int argc, char *argv[])
   {
   timer tim_main("Main timer");
   
   // Read User Parameters
   arguments userargs(argc, argv);
   arguments_multi_interleaver minter;
   userargs.add_processor(&minter);
   arguments_interleaver inter;
   userargs.add_processor(&inter);
   arguments_snr snr;
   userargs.add_processor(&snr);
   arguments_tol tol;
   userargs.add_processor(&tol);
   arguments_turbo tdec;
   userargs.add_processor(&tdec);
   arguments_mpi mpi;
   userargs.add_processor(&mpi);
   userargs.process();

   // Check parameters
   const double SNRmax = snr.get_max();
   const double SNRmin = snr.get_min();
   const double SNRstep = snr.get_step();
   if(SNRmax < SNRmin || SNRstep <= 0)
      {
      cerr << "Invalid SNR parameters: " << SNRmin << ", " << SNRmax << ", " << SNRstep << "\n";
      exit(1);
      }
   // Codec parameters
   const int iterations = tdec.get_iterations();
   // Interleaver and related parameters
   fsm *encoder;
   int tau;
   bool simile, endatzero;
   vector<interleaver *> intv;
   if(minter.get_defined())
      {
      encoder = minter.get_encoder();
      tau = minter.get_tau();
      simile = minter.get_simile();
      endatzero = minter.get_endatzero();
      intv = *minter.get_inter();
      }
   else
      {
      encoder = inter.get_encoder();
      tau = inter.get_tau();
      simile = inter.get_simile();
      endatzero = inter.get_endatzero();
      intv.init(1);
      intv(0) = inter.get_inter();
      }
   // Simulation parameters
   const double confidence = tol.get_confidence();
   const double accuracy = tol.get_accuracy();
   const bool parallel = tdec.get_parallel();

   // Modulation scheme
   bpsk modem;
   // Channel Model
   awgn chan;
   // Channel Codec (punctured, iterations, simile, endatzero)
   turbo<logreal> codec(*encoder, modem, *tdec.get_punc(), chan, tau, intv, iterations, simile, endatzero, parallel);
   // Source Generator
   randgen src;
   // The complete communication system
   commsys system(&src, &chan, &codec, false);

   // The actual estimator
   montecarlo estimator(&system);
   estimator.set_confidence(confidence);
   estimator.set_accuracy(accuracy);

   // Print information on the statistical accuracy of results being worked
   cout << "#% Tolerance: " << 100*accuracy << "%\n";
   cout << "#% Confidence: " << 100*confidence << "%\n";
   cout << "#% Date: " << timer::date() << "\n";
      
   // Initialise MPI
   if(mpi.get_used())
      cmpi::enable(&argc, &argv, mpi.get_priority());

   // Work out the following for every SNR value required
   for(double SNR = SNRmin; SNR <= SNRmax; SNR += SNRstep)
      {
      chan.set_snr(SNR);

      cerr << "Simulating system at Eb/No = " << SNR << "\n";
      vector<double> estimate, tolerance;
      estimator.estimate(estimate, tolerance);
      
      cout << SNR;
      for(int i=0; i<system.count(); i++)
         cout << "\t" << estimate(i) << "\t" << estimate(i)*tolerance(i);
      cout << "\t" << estimator.get_samplecount() << "\n";
      }

   // Finalise MPI
   if(mpi.get_used())
      cmpi::disable();

   return 0;
   }

