#include "rscc.h"
#include "nrcc.h"
#include "timer.h"
#include "itfunc.h"

#include "matrix.h"
#include "vector.h"
#include <iostream.h>
#include <math.h>

// encoder  - defines the code being used
// state    - the state we're starting from at this node
// wc       - the weight of considered codeword up to this node
// wi       - the information weight up to this node
// left     - the number of symbols left to consider (including this node!)
// wmax     - the largest codeword weight considered
// tail     - a global table with weights of tails associated with each node
// A(i,w)   - [result] a matrix holding the number of codewords of weight 'w' and information weight 'i'
void followpath(fsm& encoder, const int state, const int wc, const int wi, const int left, const int wmax, const int *tail, matrix<int>& A)
   {
   const int K = encoder.num_inputs();
   for(int i=0; i<K; i++)
      {
      encoder.reset(state);
      int new_wc = weight(encoder.step(i)) + wc;
      int new_wi = weight(i) + wi;
      int new_state = encoder.state();
      if(left == 1)
         {
         new_wc += tail[new_state];
         if(new_wc <= wmax)
            A(new_wi, new_wc)++;
         }
      else if(new_wc <= wmax)
         followpath(encoder, new_state, new_wc, new_wi, left-1, wmax, tail, A);
      }
   }

int main(int argc, char *argv[])
   {
   timer tim_main("Main timer");

   // Encoder (from generator matrix)
   const int k=1, n=2, m=2;
   matrix<bitfield> gen(k, n);
   gen(0, 0) = "111";
   gen(0, 1) = "101";
   rscc encoder(k, n, gen);
   // block size
   const int tau = argc>2 ? atoi(argv[2])+m : 100;
   // largest codeword weight considered
   const int wmax = argc>1 ? atoi(argv[1]) : 10;
   // zero entry unused
   matrix<int> A(wmax+1, wmax+1);

   // initialise results array
   for(int i=1; i<=wmax; i++)
      for(int w=1; w<=wmax; w++)
         A(i,w) = 0;

   // work out weights associated with tails
   const int M = 1<<m;
   int tail[M];
   for(int s=0; s<M; s++)
      {
      tail[s] = 0;
      encoder.reset(s);
      for(int i=0; i<m; i++)
         {
         int input = fsm::tail;
         int output = encoder.step(input);
         tail[s] += weight(output);
         }
      }

   // do it
   followpath(encoder, 0, 0, 0, tau-m, wmax, tail, A);
      
   // print results
   cout << "# Chosen code:\n";
   cout << "# (" << n*tau << ", " << k*(tau-n) << ") block\n";
   cout << "# recursive convolutional code (k=" << k << ", n=" << n << ")\n";
   cout << "# generator matrix:\n";
   for(int i=0; i<n; i++)
      {
      cout << "#";
      for(int j=0; j<k; j++)
         cout << "\t" << gen(j,i);
      cout << "\n";
      }

   // weight spectrum
   cout << "# Weight Spectrum:\n";
   cout << "# i";
   for(int w=1; w<=wmax; w++)
      cout << "\tA(i," << w << ")";
   cout << "\n" << flush;

   for(int i=1; i<=wmax; i++)
      {
      cout << "# " << i;
      for(int w=1; w<=wmax; w++)
         cout << "\t" << A(i,w);
      cout << "\n" << flush;
      }

   // work the bounds for a BPSK/AWGN system
   cout << "# Modified BER Union Bound:\n";

   for(double snr_db=0; snr_db<=8; snr_db+=1)
      {
      double snr = pow(10, snr_db/10.0);
      double R = double(k*(tau-m))/double(n*tau);

      cout << snr_db;
      double bound = 0;
      for(int w=1; w<=wmax; w++)
         {
         for(int i=1; i<=wmax; i++)
            bound += A(i,w) * i/(tau-m) * Q(sqrt(2*w*R*snr));
         if(bound > 0)
            cout << "\t" << bound;
         }
      cout << "\n" << flush;
      }
   }
