#include "wavelet.h"
#include "histogram.h"
#include "picture.h"
#include "randgen.h"
#include <iostream.h>
#include <math.h>

int main(int argc, char *argv[])
   {
   if(argc < 3)
      {
      cerr << "Usage: " << argv[0] << " <infile> <outfile>\n";
      exit(1);
      }
   
   picture p;

   cerr << "Loading from file (" << argv[1] << ")\n";
   p.load(argv[1]);

   cerr << "Processing\n";

   // create a matrix with luminance values
   matrix<double> m(p.width(), p.height());
   for(int x=0; x<p.width(); x++)
      for(int y=0; y<p.height(); y++)
         m(x,y) = p(x,y).luminance();

   // do the wavelet transform of this matrix
   wavelet w;
   w.transform(m);

   // compute histogram
   histogram h(m, 100);
//   for(int i=0; i<h.bins(); i++)
//      cout << h.val(i) << "\t" << h.freq(i) << "\n";
   const double mean = h.mu();
   const double sd = h.sigma();
   cerr << "Mean = " << mean << "\n";
   cerr << "SD   = " << sd << "\n";

   // do the power & cumulative histograms
   const int nbins = 100000;
   phistogram ph(m,nbins);
   chistogram ch(m,nbins);
   double hi = 0;
   for(int i=0; i<nbins; i++)
      if(ch.freq(i) >= 0.95)
         {
         cerr << "Cumulative percentage cutoff = " << ch.freq(i) << "\n";
         cerr << "Power percentage cutoff = " << ph.freq(i) << "\n";
         hi = ch.val(i);
         break;
         }
   double lo = -hi;

   // do the truncation
   cerr << "Truncating values in [" << lo << "," << hi << "]\n";
   int count = 0;
   for(int x=0; x<p.width(); x++)
      for(int y=0; y<p.height(); y++)
         if(m(x,y) > lo && m(x,y) < hi)
            {
            m(x,y) = 0;
            count++;
            }
   const int n = p.width()*p.height();
   cerr << "Retained " << n-count << " coefficients (" << 100.0*(n-count)/n << "%)\n";

   // do the inverse transform
   w.inverse(m);

   // change back to picture
   for(int x=0; x<p.width(); x++)
      for(int y=0; y<p.height(); y++)
         p(x,y) = m(x,y);


   cerr << "Saving to file (" << argv[2] << ")\n";
   p.save(argv[2]);

   return 0;
   }
