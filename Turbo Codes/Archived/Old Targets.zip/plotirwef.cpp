#include <iostream.h>
#include <stdio.h>
#include <stdlib.h>

#include "itfunc.h"
#include "timer.h"

inline int multiplicity(int tau, int len, int n)
   {
   return int(combinationsd(tau-len+n, n));
   }

int main(int argc, char *argv[])
   {
   // First we read the table of error events from file
   if(argc < 3)
      {
      cerr << "Usage: " << argv[0] << " <errorevents.file> <tau>\n";
      exit(1);
      }
   int tau = atoi(argv[2]);
   FILE *file = fopen(argv[1], "rb");
   if(file == NULL)
      {
      cerr << "Cannot open input file <" << argv[1] << ">\n";
      exit(1);
      }
   // get the size of the required matrix
   int rows = 0;
   while(!feof(file))
      {
      int t1, t2, t3;
      while(fscanf(file, "%d%d%d", &t1, &t2, &t3) == 0)
         fscanf(file, "%*[^\n]\n");
      if(!feof(file))
         rows++;
      }
   // now read the matrix
   int data[rows][3];
   int wmax = 0;
   int wmin = 0;
   rewind(file);
   for(int i=0; i<rows; i++)
      {
      while(fscanf(file, "%d%d%d", &data[i][0], &data[i][1], &data[i][2]) == 0)
         fscanf(file, "%*[^\n]\n");
      if(data[i][2] > wmax)
         wmax = data[i][2];
      if(data[i][2] < wmin || wmin == 0)
         wmin = data[i][2];
      }
   fclose(file);
   cerr << "Read input: " << rows << " entries, wmin = " << wmin << ", wmax = " << wmax << ", tau = " << tau << "\n";

   // Now we want to work out the IRWEF - we need the multiplicity of each combination of (iw,ow)
   // for single and multiple error events. So we start by creating the results matrix.
   double A[wmax][wmax];
   for(int i=0; i<wmax; i++)
      for(int j=0; j<wmax; j++)
         A[i][j] = 0;
   // next we consider all combinations of n error events, starting with n=1
   // and continuing until there are no combinations within the required weight limit.
   int count=1;
   for(int n=1; n*wmin <= wmax; n++)
      {
      timer tim("n-event timer");
      cerr << "Computing " << n << "-event combinations...";
      // initialise an array with n pointers into the data matrix
      int ptr[n];
      for(int i=0; i<n; i++)
         ptr[i] = 0;
      // consider all combinations of n error events
      count = 0;
      bool ready = false;
      while(!ready)
         {
         // get the total length, input and output weight of this combination of n error events
         int len=0, iw=0, ow=0;
         for(int i=0; i<n && len<tau && ow<=wmax; i++)
            {
            len += data[ptr[i]][0];
            iw += data[ptr[i]][1];
            ow += data[ptr[i]][2];
            }
         // if length and weight are within limit, then update the table with its multiplicity
         if(len < tau && ow <= wmax)
            {
            // consider all error events, and divide them into n classes, such that
            // items within the same class are the same; count the number of items
            // in each class
            int cnt[n];
            for(int i=0; i<n; i++)
               cnt[i] = 0;
            for(int i=0, j=0; i<n; i++)
               {
               if(i > 0)
                  if(ptr[i] != ptr[i-1])
                     j++;
               cnt[j]++;
               }
            // from the counts worked out above, compute the number of permutations
            // see kreyszig, p. 908
            double perm = factoriald(n);
            for(int i=0; i<n; i++)
               perm /= factoriald(cnt[i]);
            // now compute the number of combinations with this (iw,ow)
            // note that this depends both on the spacing of zeros and on the order
            // of the different error events considered
            A[iw-1][ow-1] += multiplicity(tau, len, n) * perm;
            count++;
            }
         // now update the table of pointers
         int i=n-1;
         ptr[i]++;
         while(ptr[i] > rows-1)
            {
            i--;
            if(i < 0)
               {
               ready = true;
               break;
               }
            ptr[i]++;
            for(int j=i+1; j<n; j++)
               ptr[j] = ptr[j-1];
            }
         }
      cerr << count << " entries, worked in " << tim << "\n";
      }
   // finally print the acquired results
   // first print a table of ow, A(ow)
   for(int j=0; j<wmax; j++)
      {
      cout << "# " << j+1;
      double a = 0;
      for(int i=0; i<wmax; i++)
         a += A[i][j];
      cout << "\t" << a << "\n";
      }
   // then print a table of iw, ow, A(iw,ow)
   for(int i=0; i<wmax; i++)
      for(int j=0; j<wmax; j++)
         cout << i+1 << "\t" << j+1 << "\t" << A[i][j] << "\n";
   }
