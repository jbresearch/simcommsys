#include "map.h"
#include "uncoded.h"

#include "logreal.h"
#include "mpreal.h"
#include "mpgnu.h"

#include "bpsk.h"
#include "awgn.h"
#include "randgen.h"
#include "commsys.h"
#include "montecarlo.h"
#include "timer.h"
#include "cmpi.h"
#include "arguments.h"

#include <iostream.h>
#include <math.h>


int main(int argc, char *argv[])
   {
   timer tim_main("Main timer");
   
   // Read User Parameters
   arguments userargs(argc, argv);
   arguments_map mapa;
   userargs.add_processor(&mapa);
   arguments_snr snr;
   userargs.add_processor(&snr);
   arguments_tol tol;
   userargs.add_processor(&tol);
   arguments_mpi mpi;
   userargs.add_processor(&mpi);
   userargs.process();

   // Check parameters
   const double SNRmax = snr.get_max();
   const double SNRmin = snr.get_min();
   const double SNRstep = snr.get_step();
   if(SNRmax < SNRmin || SNRstep <= 0)
      {
      cerr << "Invalid SNR parameters: " << SNRmin << ", " << SNRmax << ", " << SNRstep << "\n";
      exit(1);
      }
   // Codec parameters
   const int tau = mapa.get_tau();
   const int m = mapa.get_m();
   // Simulation parameters
   const double confidence = tol.get_confidence();
   const double accuracy = tol.get_accuracy();

   // Modulation scheme
   bpsk modem;
   // Channel Model
   awgn chan;
   // Channel Codec
   codec *cdc = NULL;
   if(m > 0)
      cdc = new map<logreal>(*mapa.get_encoder(), modem, chan, tau);
   else
      cdc = new uncoded(*mapa.get_encoder(), modem, chan, tau);
   // Source Generator
   randgen src;
   // The complete communication system
   commsys system(&src, &chan, cdc);

   // The actual estimator
   montecarlo estimator(&system);
   estimator.set_confidence(confidence);
   estimator.set_accuracy(accuracy);
   
   // Print information on the statistical accuracy of results being worked
   cout << "#% Tolerance: " << 100*accuracy << "%\n";
   cout << "#% Confidence: " << 100*confidence << "%\n";
   cout << "#% Date: " << timer::date() << "\n";
      
   // Initialise MPI
   if(mpi.get_used())
      cmpi::enable(&argc, &argv, mpi.get_priority());

   // Work out the following for every SNR value required
   for(double SNR = SNRmin; SNR <= SNRmax; SNR += SNRstep)
      {
      chan.set_snr(SNR);

      cerr << "Simulating system at Eb/No = " << SNR << "\n";
      vector<double> estimate, tolerance;
      estimator.estimate(estimate, tolerance);
      
      cout << SNR;
      for(int i=0; i<system.count(); i++)
         cout << "\t" << estimate(i) << "\t" << estimate(i)*tolerance(i);
      cout << "\t" << estimator.get_samplecount() << "\n";
      }

   // Finalise MPI
   if(mpi.get_used())
      cmpi::disable();
   
   return 0;
   }

