#include "picture.h"
#include "secant.h"
#include "atmfilter.h"

#include "turbo.h"
#include "logreal.h"
#include "rscc.h"
#include "stream_lut.h"
#include "puncture_null.h"
#include "bpsk.h"
#include "laplacian.h"

#include "randgen.h"
#include "vector.h"
#include "timer.h"

#include <stdio.h>
#include <iostream.h>
#include <math.h>

// clips a real value into [1,0]
inline double limit(const double x)
   {
   if(x > 1.0)
      return 1.0;
   if(x < 0.0)
      return 0.0;
   return x;
   }

// converts a real value by clipping into [1,0] to an integer between (1<<bits)-1 and 0
inline double quantize(const double x, const int bits)
   {
   const int m = (1<<bits)-1;
   return floor(m*limit(x) + 0.5)/m;
   }

// piecewise linear modulation
inline double plmod(const double u)
   {
   if(u >= 0 && u < 0.5)
      return u + 0.5;
   if(u > 0.5 && u <= 1)
      return u - 0.5;
   return 0;
   }

int main(int argc, char *argv[])
   {
   // read and interpret program arguments
   if(argc < 4)
      {
      cerr << "Usage: " << argv[0] << " <infile> <outfile> <snr>\n";
      exit(1);
      }
   const double snr = atof(argv[3]);
   
   // stuff that is used repeatedly
   randgen r;

   // read image and convert to a matrix
   cerr << "Loading from file (" << argv[1] << ")\n";
   picture p;
   p.load(argv[1]);
   matrix<double> f = p.luminance();
   const int M = f.x_size();;
   const int N = f.y_size();

   // Encoder (from generator matrix)
   const int _k=1, _n=2, _m=4;
   matrix<bitfield> gen(_k, _n);
   gen(0, 0) = "11111";
   gen(0, 1) = "10001";
   rscc encoder(_k, _n, gen);
   // Block interleavers from file
   vector<interleaver *> inter(2);
   FILE *file = fopen("sai-16384_4-type15_2-0.dat","rb");
   if(file == NULL)
      {
      cerr << "Failed to open interleaver file.\n";
      exit(1);
      }
   const int tau = 16384;
   inter(0) = new stream_lut(file, tau);
   inter(1) = new stream_lut(file, tau);
   fclose(file);
   // Null puncturing
   const int sets = 3;
   puncture_null punc(tau, _k+sets*(_n-_k));

   // Modulation scheme
   bpsk modem;
   // Channel Model
   laplacian chan;
   // Channel Codec (punctured, iterations, simile, endatzero)
   turbo<logreal> codec(encoder, modem, punc, chan, tau, inter, 10, true, true, false);

   // create random message
   cerr << "Creating random message\n";
   matrix<int> x(M, N);
   r.seed(0);
   for(int i=0; i<M; i++)
      for(int j=0; j<N; j++)
         x(i,j) = r.ival(2);

   // generate pseudo-random waveform
   cerr << "Generating pseudo-random waveform\n";
   matrix<double> u(M, N);
   r.seed(1);
   for(int i=0; i<M; i++)
      for(int j=0; j<N; j++)
         u(i,j) = r.fval();

   // modulate waveform based on message
   cerr << "Modulating waveform by message\n";
   matrix<double> v(M, N);
   for(int i=0; i<M; i++)
      for(int j=0; j<N; j++)
         v(i,j) = x(i,j) ? plmod(u(i,j)) : u(i,j);

   // construct embedded signal by converting to gaussian deviates
   cerr << "Transforming into Gaussian at given Peak SNR\n";
   matrix<double> s(M, N);
   secant erfinv(erf);
   const double sigma = pow(10, -snr/20.0);
   for(int i=0; i<M; i++)
      for(int j=0; j<N; j++)
         s(i,j) = erfinv(2*v(i,j)-1) * sigma;

   // embed signal in image
   cerr << "Embedding signal in image\n";
   matrix<double> g(M, N);
   for(int i=0; i<M; i++)
      for(int j=0; j<N; j++)
         g(i,j) = quantize(f(i,j)+s(i,j),8);

   // extract signal
   cerr << "Extracting signal\n";
   s = atmfilter(g,1,1);
   for(int i=0; i<M; i++)
      for(int j=0; j<N; j++)
         s(i,j) = g(i,j) - s(i,j);

   // scale back to unit variance
   double sum=0, sumsq=0;
   int n=0;
   for(int i=0; i<M; i++)
      for(int j=0; j<N; j++)
         {
         sum += s(i,j);
         sumsq += s(i,j) * s(i,j);
         n++;
         }
   const double mean = sum/n;
   const double var = sumsq/n - mean*mean;
   const double sigma_est = sqrt(var);
   for(int i=0; i<M; i++)
      for(int j=0; j<N; j++)
         s(i,j) /= sigma_est;

   // reconvert to uniform deviates
   cerr << "Transforming back into uniform\n";
   matrix<double> w(M, N);
   for(int i=0; i<M; i++)
      for(int j=0; j<N; j++)
         w(i,j) = (erf(s(i,j))+1)/2;

   // demodulate
   cerr << "Demodulating waveform\n";
   matrix<int> y(M, N);
   for(int i=0; i<M; i++)
      for(int j=0; j<N; j++)
         {
         const double z1 = fabs(w(i,j)-u(i,j));
         const double z2 = fabs(w(i,j)-plmod(u(i,j)));
         y(i,j) = (z2 < z1);
         }

   // compute error rate
   int e=0;
   for(int i=0; i<M; i++)
      for(int j=0; j<N; j++)
         if(x(i,j) != y(i,j))
            e++;
   cerr << "Error rate = " << double(e)/n << " (" << e << " bits)\n";

   // output some other statistics
   cerr << "Actual sigma = " << sigma << "\n";
   cerr << "Estimated sigma = " << sigma_est << "\n";

   // compute statistics for the channel error
   sum = sumsq = 0;
   n = 0;
   for(int i=0; i<M; i++)
      for(int j=0; j<N; j++)
         {
         const double ew = w(i,j) - v(i,j);
         sum += ew;
         sumsq += ew * ew;
         n++;
         }
   const double ch_mean = sum/n;
   const double ch_var = sumsq/n - ch_mean*ch_mean;
   const double ch_sigma = sqrt(ch_var);
   const double ch_lambda = ch_sigma/sqrt(2);
   cerr << "Channel model: sigma = " << ch_sigma << ", mu = " << ch_mean << ", lambda = " << ch_lambda << "\n";
   for(double R=1.0; R>=1.0/64.0; R/=2.0)
      cerr << "               SNR = " << -20*log10(8*ch_lambda*sqrt(R)) << " dB at R = 1/" << 1/R << "\n";

   // save filtered version
   //cerr << "Saving to file (" << argv[2] << ")\n";
   //p.save(argv[2]);

   return 0;
   }
