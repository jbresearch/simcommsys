#include "arguments.h"
#include "timer.h"
#include "itfunc.h"

#include "matrix.h"
#include "vector.h"
#include <iostream.h>
#include <math.h>

// encoder  - defines the code being used
// state    - the state we're starting from at this node
// len      - the length of the input sequence considered up to this point
// wc       - the weight of considered codeword up to this node
// wi       - the information weight up to this node
// wmax     - the largest ouptut weight considered
void followpath(fsm& encoder, const int state, const int len, const int wi, const int wc, const int wmax)
   {
   static const int K = encoder.num_inputs();
   for(int i=0; i<K; i++)
      {
      encoder.reset(state);
      int new_wc = weight(encoder.step(i)) + wc;
      int new_wi = weight(i) + wi;
      int new_state = encoder.state();
      int new_len = len+1;
      if(new_wc > wmax)
         continue;
      if(new_state != 0)
         followpath(encoder, new_state, new_len, new_wi, new_wc, wmax);
      else if(new_wc > 0)
         cout << new_len << "\t" << new_wi << "\t" << new_wc << "\n" << flush;
      }
   }

int main(int argc, char *argv[])
   {
   timer tim_main("Main timer");

   cerr << "Note: <tau> is the largest codeword weight considered.\n";

   // Read User Parameters
   arguments userargs(argc, argv);
   arguments_map mapa;
   userargs.add_processor(&mapa);
   userargs.process();

   fsm *encoder = mapa.get_encoder();
   const int wmax = mapa.get_tau();

   // print header
   cout << "# Chosen code:\n";
   cout << "# ";
   encoder->print(cout);
   cout << "\n";
   cout << "# Considering error events up to weight " << wmax << "\n";

   // do it
   followpath(*encoder, 0, 0, 0, 0, wmax);
   }
