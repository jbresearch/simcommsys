#include "diffturbo.h"

#include "logreal.h"
#include "bpsk.h"
#include "awgn.h"
#include "randgen.h"
#include "commsys.h"
#include "montecarlo.h"
#include "timer.h"
#include "cmpi.h"
#include "arguments.h"

#include <iostream.h>
#include <math.h>
#include <string.h>


int main(int argc, char *argv[])
   {
   timer tim_main("Main timer");
   
   // Read User Parameters
   arguments userargs(argc, argv);
   arguments_interleaver inter;
   userargs.add_processor(&inter);
   arguments_snr snr;
   userargs.add_processor(&snr);
   arguments_tol tol;
   userargs.add_processor(&tol);
   arguments_turbo tdec;
   userargs.add_processor(&tdec);
   userargs.process();

   // Check parameters
   const double SNRmax = snr.get_max();
   const double SNRmin = snr.get_min();
   const double SNRstep = snr.get_step();
   if(SNRmax < SNRmin || SNRstep <= 0)
      {
      cerr << "Invalid SNR parameters: " << SNRmin << ", " << SNRmax << ", " << SNRstep << "\n";
      exit(1);
      }
   // Codec parameters
   const int tau = inter.get_tau();
   const bool simile = inter.get_simile();
   const bool endatzero = inter.get_endatzero();
   const int iterations = tdec.get_iterations();
   // Simulation parameters
   const double confidence = tol.get_confidence();
   const double accuracy = tol.get_accuracy();

   // Modulation scheme
   bpsk modem;
   // Channel Model
   awgn chan;
   // Channel Codec (punctured, iterations, simile, endatzero)
   diffturbo<logreal> codec("/home/jabrif/tcodes/results/berrou-16.lut", *inter.get_encoder(), modem, *tdec.get_punc(), chan, tau, inter.get_vinter(), iterations, simile, endatzero);
   // Source Generator
   randgen src;
   // The complete communication system
   commsys system(&src, &chan, &codec);

   // The actual estimator
   montecarlo estimator(&system);
   estimator.set_confidence(confidence);
   estimator.set_accuracy(accuracy);

   // Print information on the statistical accuracy of results being worked
   cout << "#% Tolerance: " << 100*accuracy << "%\n";
   cout << "#% Confidence: " << 100*confidence << "%\n";
   cout << "#% Date: " << timer::date() << "\n";
      
   // Initialise MPI
   cmpi::enable(&argc, &argv);

   // Work out the following for every SNR value required
   for(double SNR = SNRmin; SNR <= SNRmax; SNR += SNRstep)
      {
      chan.set_snr(SNR);

      cerr << "Simulating system at Eb/No = " << SNR << "\n";
      vector<double> estimate, tolerance;
      estimator.estimate(estimate, tolerance);
      
      cout << SNR;
      for(int i=0; i<system.count(); i++)
         cout << "\t" << estimate(i) << "\t" << estimate(i)*tolerance(i);
      cout << "\n";
      }

   // Finalise MPI
   cmpi::disable();

   return 0;
   }

