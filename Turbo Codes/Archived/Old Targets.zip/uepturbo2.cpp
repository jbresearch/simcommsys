#include "turbo.h"
#include "puncture_null.h"
#include "logreal.h"
#include "bpsk.h"
#include "awgn.h"
#include "timer.h"
#include "arguments.h"

#include <iostream.h>
#include <math.h>
#include <string.h>

class uepturbo : protected turbo<logreal> {
public:
   uepturbo(fsm& encoder, modulator& modem, puncture& punc, channel& chan, const int tau, vector<interleaver *>& inter, const int iter, const bool simile, const bool endatzero);
   ~uepturbo();

   void reset(matrix<double>& confidence);
   void delta(matrix<double>& confidence, int k, int t, int i);
   void analyse(matrix<double>& confidence);
};

uepturbo::uepturbo(fsm& encoder, modulator& modem, puncture& punc, channel& chan, const int tau, vector<interleaver *>& inter, const int iter, const bool simile, const bool endatzero) : turbo<logreal>(encoder, modem, punc, chan, tau, inter, iter, simile, endatzero)
   {
   if(K > 2)
      {
      cerr << "FATAL ERROR (uepturbo): only binary input codes are handled by this implementation.\n";
      exit(1);
      }
   }

uepturbo::~uepturbo()
   {
   }

void uepturbo::reset(matrix<double>& confidence)
   {
   confidence.init(tau*s, tau);
   for(int k=0; k<tau*s; k++)
      for(int j=0; j<tau; j++)
         confidence(k,j) = 0;
   }

void uepturbo::delta(matrix<double>& confidence, int k, int t, int i)
   {
   vector<int> source(tau), encoded(tau);
   vector<sigspace> rx(tau*s);

   // Create an all-zero source, encode it and modulate it
   for(int j=0; j<tau; j++)
      source(j) = 0;
   encode(source, encoded);
   modulate(encoded, rx);

   // Corrupt the modulation symbols (simulate the channel, using deterministic pattern)
   // For BPSK, this results in equal probability of 1 and 0
   rx(t*s+i) = sigspace(0, 0);

   // Now, demodulate the corrupted sequence and decode it (do all iterations)
   demodulate(rx);
   for(int j=0; j<iter; j++)
      decode(source);

   // Finally, we compute the confidence at the input side
   for(int j=0; j<tau; j++)
      confidence(k,j) += log(ri(j, 0) / ri(j, 1));
   }

void uepturbo::analyse(matrix<double>& confidence)
   {
   reset(confidence);
   for(int t=0; t<tau; t++)
      for(int i=0; i<s; i++)
         delta(confidence, t*s+i, t, i);
   }

int main(int argc, char *argv[])
   {
   timer tim_main("Main timer");
   
   // Read User Parameters
   arguments userargs(argc, argv);
   arguments_interleaver inter;
   userargs.add_processor(&inter);
   arguments_turbo tdec;
   userargs.add_processor(&tdec);
   userargs.process();

   // Codec parameters
   const int tau = inter.get_tau();
   const bool simile = inter.get_simile();
   const bool endatzero = inter.get_endatzero();
   const int iterations = tdec.get_iterations();

   // Modulation scheme
   bpsk modem;
   // Channel Model
   awgn chan;
   // Channel Codec (punctured, iterations, simile, endatzero)
   uepturbo codec(*inter.get_encoder(), modem, *tdec.get_punc(), chan, tau, inter.get_vinter(), iterations, simile, endatzero);

   // Work out the results
   matrix<double> confidence;
   codec.analyse(confidence);

   // Print the results
   cout << "#% Date: " << timer::date() << "\n";
   for(int k=0; k<confidence.x_size(); k++)
      {
      cout << confidence(k,0);
      for(int i=1; i<tau; i++)
         cout << "\t" << confidence(k,i);
      cout << "\n";
      }

   return 0;
   }
