#include <iostream.h>
#include <stdlib.h>
#include <stdio.h>
#include "randgen.h"


int main(int argc, char *argv[])
   {
   // get user parameters
   if(argc < 3)
      {
      cerr << "Usage: " << argv[0] << " <length/sec> <file>\n";
      exit(1);
      }
   const int freq = 44100;
   int length = atoi(argv[1])*freq;

   // create the file
   FILE *file = fopen(argv[2], "wb");
   if(file == NULL)
      {
      cerr << "Failed to open file (" << argv[2] << ")\n";
      exit(1);
      }
   // write noise
   randgen r;
   r.seed(0);
   for(int i=0; i<length; i++)
      {
      int16s x = int(floor(r.gval(double(1<<15)/10) + 0.5));
      fwrite(&x, sizeof(int16s), 1, file);
      }
   // close file
   fclose(file);

   return 0;
   }
