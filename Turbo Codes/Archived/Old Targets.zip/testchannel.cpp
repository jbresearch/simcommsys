#include "laplacian.h"
#include "matrix.h"
#include "vector.h"

#include <fstream.h>

int main()
   {
   laplacian ch;
   ch.seed(0);
   ch.set_eb(1);
   ch.set_snr(20);   // Eb/No = 20dB  =>  for Eb=1, No=0.01  =>  sigma = sqrt(No/2) = 0.0707 (cf mphil p.43)
   
   // create the pdf matrix
   // this has N entries from -1 to +1 both inclusive
   const int N = 101;
   const double step = 2/double(N-1);
   matrix<double> pdf(N,N);
   for(int i=0; i<N; i++)
      for(int j=0; j<N; j++)
         {
         const sigspace tx(0,0);
         const sigspace rx(-1+i*step, -1+j*step);
         pdf(i,j) = ch.pdf(tx,rx);
         }

   // create a noise vector
   const int M = 10000;
   vector<double> eta(M);
   for(int i=0; i<M; i++)
      {
      const sigspace tx(0,0);
      const sigspace rx = ch.corrupt(tx);
      eta(i) = rx.i();
      }

   // output stuff
   std::ofstream file;
   
   file.open("channel-pdf.txt");
   file << pdf;
   file.close();

   file.open("channel-eta.txt");
   file << eta;
   file.close();

   return 0;
   }
