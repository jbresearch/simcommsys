/*******************************************************************/
/*                                                                 */
/*                      ADOBE CONFIDENTIAL                         */
/*                   _ _ _ _ _ _ _ _ _ _ _ _ _                     */
/*                                                                 */
/* Copyright 2000 Adobe Systems Incorporated                       */
/* All Rights Reserved.                                            */
/*                                                                 */
/* NOTICE:  All information contained herein is, and remains the   */
/* property of Adobe Systems Incorporated and its suppliers, if    */
/* any.  The intellectual and technical concepts contained         */
/* herein are proprietary to Adobe Systems Incorporated and its    */
/* suppliers and may be covered by U.S. and Foreign Patents,       */
/* patents in process, and are protected by trade secret or        */
/* copyright law.  Dissemination of this information or            */
/* reproduction of this material is strictly forbidden unless      */
/* prior written permission is obtained from Adobe Systems         */
/* Incorporated.                                                   */
/*                                                                 */
/*******************************************************************/
//-------------------------------------------------------------------------------
#include "PIDefines.h"
#include "ASTypes.h"
#include "PIAbout.h"
#include "PIFilter.h"

FilterRecord*	gFilterRecord;
int32*			gData;
int16*			gResult;

DLLExport SPAPI void PluginMain(const int16 selector,
                                FilterRecord* filterRecord,
                                int32* data,
                                int16* result);
void DoAbout(void);
void DoParameters(void);
void DoPrepare(void);
void DoStart(void);
void DoContinue(void);
void DoFinish(void);

void InvertTile(void* tileData, Rect* tileRect, int32 rowBytes);

DLLExport SPAPI void PluginMain(const int16 selector,
                                FilterRecord* filterRecord,
                                int32* data,
                                int16* result)
   {
   gFilterRecord = filterRecord;
   gData = data;
   gResult = result;
   
   switch (selector)
      {
      case filterSelectorAbout:
         DoAbout();
         break;
      case filterSelectorParameters:
         DoParameters();
         break;
      case filterSelectorPrepare:
         DoPrepare();
         break;
      case filterSelectorStart:
         DoStart();
         break;
      case filterSelectorContinue:
         DoContinue();
         break;
      case filterSelectorFinish:
         DoFinish();
         break;
      default:
         *gResult = filterBadParameters;
         break;
      }
   }

void DoAbout(void)
   {
   AboutRecord* aboutRecord = (AboutRecord*)gFilterRecord;
   }

void DoParameters(void)
   {
   }

void DoPrepare(void)
   {
   gFilterRecord->bufferSpace = 0;
   gFilterRecord->maxSpace = 0;
   }

void DoStart(void)
   {
   int16 tileHeight = gFilterRecord->outTileHeight;
   int16 tileWidth = gFilterRecord->outTileWidth;
   
   if (tileWidth==0 || tileHeight==0 || gFilterRecord->advanceState==NULL)
      {
      *gResult = filterBadParameters;
      return;
      }
   
   Rect* outRect = &gFilterRecord->outRect;
   Point* imageSize = &gFilterRecord->imageSize;
   
   uint16 tilesVert = imageSize->v / tileHeight;
   uint16 tilesHoriz = imageSize->h / tileWidth;
   
   int16 layerPlanes = 0;
   if (gFilterRecord->filterCase > 2)
      layerPlanes = gFilterRecord->outLayerPlanes;
   else
      layerPlanes = gFilterRecord->planes;
   
   int32 progress_total = layerPlanes * tilesVert;
   int32 progress_complete = 0;
   
   for(int16 planeCount = 0; planeCount < layerPlanes; planeCount++)
      {
      gFilterRecord->outLoPlane = planeCount;
      gFilterRecord->outHiPlane = planeCount;
      
      for(uint16 vertTile = 0; vertTile <= tilesVert; vertTile++)
         {
         for(uint16 horizTile = 0; horizTile <= tilesHoriz; horizTile++)
            {
            outRect->top = vertTile * tileHeight;
            outRect->left = horizTile * tileWidth;
            outRect->bottom = outRect->top + tileHeight;
            outRect->right = outRect->left + tileWidth;
            
            if (outRect->bottom > imageSize->v)
               outRect->bottom = imageSize->v;
            if (outRect->right > imageSize->h)
               outRect->right = imageSize->h;
            
            *gResult = gFilterRecord->advanceState();
            if (*gResult != kNoErr) return;
            
            InvertTile(gFilterRecord->outData, 
               &gFilterRecord->outRect, 
               gFilterRecord->outRowBytes);
            }
         
         gFilterRecord->progressProc(++progress_complete, progress_total);
         
         if (gFilterRecord->abortProc()) 
            {
            *gResult = userCanceledErr;
            goto done;
            }
         }
      }
done:
   outRect->top = 0;
   outRect->left = 0;
   outRect->bottom = 0;
   outRect->right = 0;
   }

void DoContinue(void)
   {
   *gResult = filterBadParameters;
   }

void DoFinish(void)
   {
   }

void InvertTile(void* tileData, Rect* tileRect, int32 rowBytes)
   {
   uint8* smallPixel = (uint8*)tileData;
   uint16* largePixel = (uint16*)tileData;
   Rect* outRect = tileRect;
   
   uint16 rectHeight = outRect->bottom - outRect->top;
   uint16 rectWidth = outRect->right - outRect->left;
   
   for(uint16 pixelY = 0; pixelY < rectHeight; pixelY++)
      {
      for(uint16 pixelX = 0; pixelX < rectWidth; pixelX++)
         {
         if (gFilterRecord->depth == 16)
            {
            *largePixel ^= 0x7fff;
            largePixel++;
            } 
         else
            {
            *smallPixel ^= 0xff;
            smallPixel++;
            }
         }
      smallPixel += rowBytes - rectWidth;
      largePixel += rowBytes / 2 - rectWidth;
      }
   }
