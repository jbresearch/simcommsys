// CMFCShellDlg.cpp : implementation file
//

#include "stdafx.h"
#include "MFCShell.h"
#include "MFCShellDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CAboutDlg dialog used for App About

CAboutDlg::CAboutDlg() : CDialog(CAboutDlg::IDD)
   {
   //{{AFX_DATA_INIT(CAboutDlg)
   //}}AFX_DATA_INIT
   }

void CAboutDlg::DoDataExchange(CDataExchange* pDX)
   {
   CDialog::DoDataExchange(pDX);
   //{{AFX_DATA_MAP(CAboutDlg)
   //}}AFX_DATA_MAP
   }

BEGIN_MESSAGE_MAP(CAboutDlg, CDialog)
//{{AFX_MSG_MAP(CAboutDlg)
// No message handlers
//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CMFCShellDlg dialog

CMFCShellDlg::CMFCShellDlg(CWnd* pParent /*=NULL*/)
: CDialog(CMFCShellDlg::IDD, pParent)
   {
   //{{AFX_DATA_INIT(CMFCShellDlg)
	m_nAlpha = 0;
	m_nRadius = 0;
	//}}AFX_DATA_INIT
   }


void CMFCShellDlg::DoDataExchange(CDataExchange* pDX)
   {
   CDialog::DoDataExchange(pDX);
   //{{AFX_DATA_MAP(CMFCShellDlg)
	DDX_Text(pDX, IDC_ALPHA, m_nAlpha);
	DDX_Text(pDX, IDC_RADIUS, m_nRadius);
	//}}AFX_DATA_MAP
   }


BEGIN_MESSAGE_MAP(CMFCShellDlg, CDialog)
//{{AFX_MSG_MAP(CMFCShellDlg)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CMFCShellDlg message handlers

BOOL CMFCShellDlg::OnInitDialog() 
   {
   CDialog::OnInitDialog();
   
   return TRUE;  // return TRUE unless you set the focus to a control
   // EXCEPTION: OCX Property Pages should return FALSE
   }
