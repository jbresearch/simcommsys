// MFCShell.h : main header file for the MFCShell DLL
//

#if !defined(AFX_MFCShell_H__57DC22DD_6AEA_11D3_BD7B_0060B0A13DC4__INCLUDED_)
#define AFX_MFCShell_H__57DC22DD_6AEA_11D3_BD7B_0060B0A13DC4__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#ifndef __AFXWIN_H__
   #error include 'stdafx.h' before including this file for PCH
#endif

#include "resource.h"      // main symbols

/////////////////////////////////////////////////////////////////////////////
// SMFCShellData
//

struct SMFCShellData {
   int   nAlpha;
   int   nRadius;
   };

/////////////////////////////////////////////////////////////////////////////
// CMFCShellApp
// See MFCShell.cpp for the implementation of this class
//

class CMFCShellApp : public CWinApp
{
protected:
   FilterRecord*  m_pFilterRecord;
   long*          m_pData;
   SMFCShellData* m_sData;
   bool           m_bShowDialog;
   int16          m_nPlane;
   int16          m_nVerTile;
   int16          m_nHorTile;

protected:
   double GetPixelValue(const int x, const int y);
   void SetPixelValue(const int x, const int y, const double c);
   void CopyTile(void);
   void ResetTile(void);
   void WriteTile(const int nOverlap=0);
   void UpdateTile(const int nOverlap=0);
   void ShowDialog(void);

public:
   CMFCShellApp();

   void Entry(FilterRecord* pFilterRecord, long* pData);
   void Exit();

   void FilterAbout(void);
   void FilterParameters(void);
   void FilterPrepare(void);
   void FilterStart(void);
   void FilterContinue(void);
   void FilterFinish(void);

// Overrides
   // ClassWizard generated virtual function overrides
   //{{AFX_VIRTUAL(CMFCShellApp)
   //}}AFX_VIRTUAL

   //{{AFX_MSG(CMFCShellApp)
      // NOTE - the ClassWizard will add and remove member functions here.
      //    DO NOT EDIT what you see in these blocks of generated code !
   //}}AFX_MSG
   DECLARE_MESSAGE_MAP()
};


/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_MFCShell_H__57DC22DD_6AEA_11D3_BD7B_0060B0A13DC4__INCLUDED_)
