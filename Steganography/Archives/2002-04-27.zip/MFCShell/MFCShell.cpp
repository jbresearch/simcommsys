// MFCShell.cpp : Defines the initialization routines for the DLL.
//

#include "stdafx.h"
#include "MFCShell.h"
#include "MFCShellDlg.h"
#include <math.h>

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CMFCShellApp

BEGIN_MESSAGE_MAP(CMFCShellApp, CWinApp)
//{{AFX_MSG_MAP(CMFCShellApp)
// NOTE - the ClassWizard will add and remove mapping macros here.
//    DO NOT EDIT what you see in these blocks of generated code!
//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CMFCShellApp construction

CMFCShellApp::CMFCShellApp()
   {
   // TODO: add construction code here,
   // Place all significant initialization in InitInstance
   m_pFilterRecord = NULL;
   m_pData = NULL;
   }

/////////////////////////////////////////////////////////////////////////////
// CMFCShellApp entry and exit points

// this gets called every time through the main() loop so we stay in sync
void CMFCShellApp::Entry(FilterRecord* pFilterRecord, long* pData)
   {
   if(pFilterRecord == NULL)
      throw("pFilterRecord == NULL in CMFCShellApp::Entry");
   m_pFilterRecord = pFilterRecord;
   m_pData = pData;
   }

// I am not sure if I need this, every time we go back to Photoshop you could
// set some stuff up here????, I was thinking about releasing the suites and
// then reacquiring on the Entry() call, but that means lots of acquire and
// release
void CMFCShellApp::Exit()
   {
   if((char**)*m_pData != NULL)
      m_pFilterRecord->handleProcs->unlockProc((Handle)*m_pData);
   }

/////////////////////////////////////////////////////////////////////////////
// CMFCShellApp filter selector functions

// show the about dialog here
void CMFCShellApp::FilterAbout(void)
   {
   CAboutDlg dlg;
   dlg.DoModal();
   }

// this will be called the first time your plug in is ran
// if it's zero create a handle and store our default value in there
void CMFCShellApp::FilterParameters(void)
   {
   if(*m_pData == NULL)
      {
      // allocate memory for parameters
      char** sHandle = m_pFilterRecord->handleProcs->newProc(sizeof(SMFCShellData));
      if(sHandle == NULL)
         throw("No handle created in CMFCShellApp::Parameters");
      m_sData = (SMFCShellData *)m_pFilterRecord->handleProcs->lockProc(sHandle, true);
      if(m_sData == NULL)
         throw("No pointer to data in CMFCShellApp::Parameters");
      *m_pData = (long)sHandle;
      // intialise parameters
      m_sData->nAlpha = 1;
      m_sData->nRadius = 1;
      }
   m_bShowDialog = true;
   }

// the plug in could start here with the Ctrl-F command, "Run Last Filter"
// you better have a valid handle to get your data out of
void CMFCShellApp::FilterPrepare(void)
   {
   m_sData = (SMFCShellData *)m_pFilterRecord->handleProcs->lockProc((char**)*m_pData, true);
   if(m_sData == NULL)
      throw("No pointer to data in CMFCShellApp::Prepare");
   }

void CMFCShellApp::FilterStart(void)
   {
   // show user dialog to get parameters, as required
   if(m_bShowDialog)
      ShowDialog();

   // select the first rectangle based on the given tile suggestions
   m_nPlane = 0;
   m_nVerTile = 0;
   m_nHorTile = 0;
   WriteTile();
   }

void CMFCShellApp::FilterContinue(void)
   {
   // do the processing for this tile
   const Rect* TileRect = &m_pFilterRecord->inRect;
   const int nTileWidth = TileRect->right - TileRect->left;
   const int nTileHeight = TileRect->bottom - TileRect->top;

   for(int y=0; y<nTileHeight; y++)
      for(int x=0; x<nTileWidth; x++)
         SetPixelValue(x, y, 1-GetPixelValue(x,y));

   // select the next rectangle based on the given tile suggestions
   UpdateTile();
   }

void CMFCShellApp::FilterFinish(void)
   {
   }

/////////////////////////////////////////////////////////////////////////////
// CMFCShellApp helper functions

double CMFCShellApp::GetPixelValue(const int x, const int y)
   {
   const bool bWide = (m_pFilterRecord->depth == 16);
   const int nRowWidth = bWide ? m_pFilterRecord->inRowBytes/2 : m_pFilterRecord->inRowBytes;
   uint8* nSmallPixel = (uint8*) m_pFilterRecord->inData;
   uint16* nLargePixel = (uint16*) m_pFilterRecord->inData;
   const int nOffset = y*nRowWidth + x;
   if(bWide)
      return nLargePixel[nOffset] / double(0x7fff);
   else
      return nSmallPixel[nOffset] / double(0xff);
   }

void CMFCShellApp::SetPixelValue(const int x, const int y, const double c)
   {
   const bool bWide = (m_pFilterRecord->depth == 16);
   const int nRowWidth = bWide ? m_pFilterRecord->outRowBytes/2 : m_pFilterRecord->outRowBytes;
   uint8* nSmallPixel = (uint8*) m_pFilterRecord->outData;
   uint16* nLargePixel = (uint16*) m_pFilterRecord->outData;
   const int nOffset = y*nRowWidth + x;
   if(bWide)
      nLargePixel[nOffset] = (uint16) (c * 0x7fff);
   else
      nSmallPixel[nOffset] = (uint8) (c * 0xff);
   }

void CMFCShellApp::CopyTile(void)
   {
   // set up aliases for filter record values we're using
   Rect* inRect  = &m_pFilterRecord->inRect;
   Rect* outRect = &m_pFilterRecord->outRect;

   // copy the output rectangle and plane from the input
   outRect->left = inRect->left;
   outRect->top = inRect->top;
   outRect->right = inRect->right;
   outRect->bottom = inRect->bottom;

   m_pFilterRecord->outLoPlane = m_pFilterRecord->inLoPlane;
   m_pFilterRecord->outHiPlane = m_pFilterRecord->inHiPlane;
   }

void CMFCShellApp::ResetTile(void)
   {
   // set up aliases for filter record values we're using
   Rect* inRect  = &m_pFilterRecord->inRect;

   // define input rectangle and plane as null
   inRect->top = 0;
   inRect->left = 0;
   inRect->bottom = 0;
   inRect->right = 0;

   m_pFilterRecord->inLoPlane = 0;
   m_pFilterRecord->inHiPlane = 0;

   // copy the output rectangle and plane from the input
   CopyTile();
   }

void CMFCShellApp::WriteTile(const int nOverlap)
   {
   // set up aliases for filter record values we're using
   const int16 nTileHeight = m_pFilterRecord->outTileHeight;
   const int16 nTileWidth = m_pFilterRecord->outTileWidth;
   const Point* imageSize = &m_pFilterRecord->imageSize;
   Rect* inRect  = &m_pFilterRecord->inRect;

   // select the input rectangle coordinates & plane
   inRect->left = m_nHorTile * (nTileWidth - nOverlap);
   inRect->top = m_nVerTile * (nTileHeight - nOverlap);
   inRect->right = inRect->left + nTileWidth;
   inRect->bottom = inRect->top + nTileHeight;

   if(inRect->right > imageSize->h)
      inRect->right = imageSize->h;
   if(inRect->bottom > imageSize->v)
      inRect->bottom = imageSize->v;

   m_pFilterRecord->inLoPlane = m_nPlane;
   m_pFilterRecord->inHiPlane = m_nPlane;

   // copy the output rectangle & plane from input
   CopyTile();
   }

void CMFCShellApp::UpdateTile(const int nOverlap)
   {
   // set up aliases for filter record values we're using
   const int16 nTileHeight = m_pFilterRecord->outTileHeight;
   const int16 nTileWidth = m_pFilterRecord->outTileWidth;
   const int16 nLayerPlanes = (m_pFilterRecord->filterCase > 2) ? m_pFilterRecord->outLayerPlanes : m_pFilterRecord->planes;
   const Point* imageSize = &m_pFilterRecord->imageSize;
   const uint16 nTilesVer = int(ceil(imageSize->v / double(nTileHeight - nOverlap)));
   const uint16 nTilesHor = int(ceil(imageSize->h / double(nTileWidth - nOverlap)));

   // find which is the next tile we need to process and update the records
   if(++m_nHorTile >= nTilesHor)
      {
      m_nHorTile = 0;
      if(++m_nVerTile >= nTilesVer)
         {
         m_nVerTile = 0;
         if(++m_nPlane >= nLayerPlanes)
            {
            ResetTile();
            return;
            }
         }
      }
   WriteTile(nOverlap);

   // update the progress counter
   const int32 nProgressTotal = nLayerPlanes * nTilesVer;
   const int32 nProgressComplete = m_nPlane * nTilesVer + m_nVerTile;
   m_pFilterRecord->progressProc(nProgressComplete, nProgressTotal);

   // see if the user cancelled
   if(m_pFilterRecord->abortProc()) 
      {
      ResetTile();
      throw((short)userCanceledErr);
      }
   }

void CMFCShellApp::ShowDialog(void)
   {
   CMFCShellDlg   dlg;

   dlg.m_pFilterRecord = m_pFilterRecord;
   dlg.m_pData = m_pData;

   dlg.m_nAlpha = m_sData->nAlpha;
   dlg.m_nRadius = m_sData->nRadius;

   int err = dlg.DoModal();
   if(err != IDOK)
      throw((short)userCanceledErr);

   m_sData->nAlpha = dlg.m_nAlpha;
   m_sData->nRadius = dlg.m_nRadius;
   m_bShowDialog = false;
   }

/////////////////////////////////////////////////////////////////////////////
// The one and only CMFCShellApp object
CMFCShellApp theApp;

DLLExport SPAPI void PluginMain(const short selector, FilterRecord* filterParamBlock, long* data, short* result)
   {
   AFX_MANAGE_STATE(AfxGetStaticModuleState());
   try
      {
      theApp.Entry(filterParamBlock, data);
      
      switch( selector )
         {
         case filterSelectorAbout:
            theApp.FilterAbout();
            break;
         case filterSelectorParameters:
            theApp.FilterParameters();
            break;
         case filterSelectorPrepare:
            theApp.FilterPrepare();
            break;
         case filterSelectorStart:
            theApp.FilterStart();
            break;
         case filterSelectorContinue:
            theApp.FilterContinue();
            break;
         case filterSelectorFinish:
            theApp.FilterFinish();
            break;
         }
      
      theApp.Exit();
      }
   
   catch(char* inErrorString)
      {
      OutputDebugString(inErrorString);
      char *pErrorString = (char*)filterParamBlock->errorString;
      if (pErrorString != NULL)
         {
         *pErrorString = strlen(inErrorString);
         for (int a=0; a < pErrorString[0]; a++)
            {
            *++pErrorString = *inErrorString++;
            }
         *pErrorString = '\0';
         }
      *result = errReportString;
      }
   
   catch(short inError)
      {
      *result = inError;
      }
   
   catch(...)
      {
      *result = -1;
      }
   }
