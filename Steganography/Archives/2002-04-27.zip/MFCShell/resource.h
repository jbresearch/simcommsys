//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by MFCShell.rc
//
#define IDD_ABOUTBOX                    100
#define IDD_DIALOG1                     1000
#define IDC_VALUE                       1000
#define IDC_PROXY                       1001
#define IDC_DEBUG                       1002
#define IDC_CUSTOM1                     1003
#define IDC_RADIUS                      1005
#define IDC_ALPHA                       1006

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        1002
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1004
#define _APS_NEXT_SYMED_VALUE           1000
#endif
#endif
