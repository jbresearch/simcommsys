#if !defined(AFX_MFCShellDlg_H__57DC22E4_6AEA_11D3_BD7B_0060B0A13DC4__INCLUDED_)
#define AFX_MFCShellDlg_H__57DC22E4_6AEA_11D3_BD7B_0060B0A13DC4__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// MFCShellDlg.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CAboutDlg dialog used for App About

class CAboutDlg : public CDialog
{
public:
   CAboutDlg();
   
   // Dialog Data
   //{{AFX_DATA(CAboutDlg)
   enum { IDD = IDD_ABOUTBOX };
   //}}AFX_DATA
   
   // ClassWizard generated virtual function overrides
   //{{AFX_VIRTUAL(CAboutDlg)
protected:
   virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
   //}}AFX_VIRTUAL
   
   // Implementation
protected:
   //{{AFX_MSG(CAboutDlg)
   //}}AFX_MSG
   DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////
// CMFCShellDlg dialog

class CMFCShellDlg : public CDialog
{
// Construction
public:
   CMFCShellDlg(CWnd* pParent = NULL);   // standard constructor

   FilterRecord*  m_pFilterRecord;
   long*          m_pData;

// Dialog Data
   //{{AFX_DATA(CMFCShellDlg)
	enum { IDD = IDD_DIALOG1 };
	int		m_nAlpha;
	int		m_nRadius;
	//}}AFX_DATA

// Overrides
   // ClassWizard generated virtual function overrides
   //{{AFX_VIRTUAL(CMFCShellDlg)
   protected:
   virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
   //}}AFX_VIRTUAL

// Implementation
protected:

   // Generated message map functions
   //{{AFX_MSG(CMFCShellDlg)
   virtual BOOL OnInitDialog();
   //}}AFX_MSG
   DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_MFCShellDlg_H__57DC22E4_6AEA_11D3_BD7B_0060B0A13DC4__INCLUDED_)
