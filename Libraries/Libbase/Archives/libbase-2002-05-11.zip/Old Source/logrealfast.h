#ifndef __logrealfast_h
#define __logrealfast_h

//#define DEBUG

#include "config.h"
#include "vcs.h"
#include "itfunc.h"
#include <math.h>
#include <float.h>
#include <stdlib.h>
#include <iostream>
#ifdef DEBUG
#  include <fstream>
#endif
using namespace std;

/*
  Version 1.10 (21 Feb 2002)
  Fixed some bugs in the LUT working of the system; also added hooks to allow debugging
  by printing to a file the difference values and the errors for all LUT access.

  Version 1.11 (22 Feb 2002)
  Optimised the choice of LUT size and range (to 128k entries over [0,12]). Also slightly
  speeded up some other routines in minor ways.

  Version 1.12 (23 Feb 2002)
  Other minor speed enhancement changes.

  Version 1.13 (6 Mar 2002)
  changed vcs version variable from a global to a static class variable.
  also changed use of iostream from global to std namespace.

  Version 1.14 (29 Mar 2002)
  modified constructor to trap infinite values and NaN; also moved constructor to
  implementation file, since it has become too large to be defined inline.

  Version 1.15 (4 Apr 2002)
  modified constructor to trap zero values first; since zero is the default argument, there
  are many more calls with this value than any other, so this should improve performance.

  Version 1.16 (4 Apr 2002)
  added default constructor to avoid going through the lengthy constructor for default.
  Also moved the LUT building code into a separate (private) function.

  Version 1.17 (6 Apr 2002)
  added assignment from double, as this would otherwise have to make use of the
  constructor, with an additional member copy. Also added a private conversion
  function that returns the logval representing a double, and modified the constructor
  to make use of that function. Also added copy constructors and copy assignment
  operators although the default (member-wise copy) will do anyway.
*/
class logrealfast {
   static const vcs version;
   static const int  lutsize;
   static const double lutrange;
   static double  *lut;
   static bool    lutready;
#ifdef DEBUG
   static ofstream file;
#endif
private:
   double logval;
   void buildlut();
   double convertfromdouble(const double m) const;
   logrealfast& operator-();
   logrealfast& operator-=(const logrealfast& a);
public:
   // construction
   logrealfast();
   logrealfast(const double m);
   logrealfast(const logrealfast& a);
   // copy assignment
   logrealfast& operator=(const logrealfast& a);
   // conversion
   operator double() const;
   logrealfast& operator=(const double m);
   // arithmetic
   logrealfast& operator+=(const logrealfast& a);
   logrealfast& operator*=(const logrealfast& a);
   logrealfast& operator/=(const logrealfast& a);
   // stream output
   friend ostream& operator<<(ostream& s, const logrealfast& x);
};

// construction operations

inline logrealfast::logrealfast()
   {
   if(!lutready)
      buildlut();
   }

inline logrealfast::logrealfast(const double m)
   {
   if(!lutready)
      buildlut();
   logval = convertfromdouble(m);
   }

inline logrealfast::logrealfast(const logrealfast& a)
   {
   // copy constructor need not check for lutready since at least one object
   // must have been created already.
   logval = a.logval;
   }

// copy assignment

inline logrealfast& logrealfast::operator=(const logrealfast& a)
   {
   logval = a.logval;
   return *this;
   }

// conversion operations

inline logrealfast::operator double() const
   {
   return exp(-logval);
   }

inline logrealfast& logrealfast::operator=(const double m)
   {
   logval = convertfromdouble(m);
   return *this;
   }

// arithmetic operations

inline logrealfast& logrealfast::operator+=(const logrealfast& a)
   {
   static const double lutinvstep = (lutsize-1)/lutrange;
   const double diff = fabs(logval - a.logval);

   if(a.logval < logval)
      logval = a.logval;

#ifdef DEBUG
   const double offset = log(1 + exp(-diff));
   logval -= offset;
#endif

   if(diff < lutrange)
      {
      const int index = round(diff*lutinvstep);
      logval -= lut[index];
#ifdef DEBUG
      file << diff << "\t" << offset - lut[index] << "\n";
#endif
      }
#ifdef DEBUG
   else
      file << diff << "\t" << offset << "\n";
#endif

   return *this;
   }
   
inline logrealfast& logrealfast::operator*=(const logrealfast& a)
   {
   logval += a.logval;
   const int inf = isinf(logval);
   if(inf < 0)
      logval = -DBL_MAX;
   else if(inf > 0)
      logval = DBL_MAX;
   return *this;
   }
   
inline logrealfast& logrealfast::operator/=(const logrealfast& a)
   {
   logval -= a.logval;
   const int inf = isinf(logval);
   if(inf < 0)
      logval = -DBL_MAX;
   else if(inf > 0)
      logval = DBL_MAX;
   return *this;
   }

// The following functions operate through the above - no need to make them friends

inline logrealfast operator+(const logrealfast& a, const logrealfast& b)
   {
   logrealfast result = a;
   result += b;
   return result;
   }

inline logrealfast operator*(const logrealfast& a, const logrealfast& b)
   {
   logrealfast result = a;
   result *= b;
   return result;
   }       
   
inline logrealfast operator/(const logrealfast& a, const logrealfast& b)
   {
   logrealfast result = a;
   result /= b;
   return result;
   }

#endif
