#ifndef __mpreal_h
#define __mpreal_h

#include "config.h"
#include "vcs.h"
#include <iostream>
using namespace std;

/*
  Version 1.01 (6 Mar 2002)
  changed vcs version variable from a global to a static class variable.
  also changed use of iostream from global to std namespace.
*/
class mpreal {
   static const vcs version;
   static const int base;
   int32s	exponent;
   long double	mantissa;
   void normalise();
public:
   mpreal(const double m=0);
   operator double() const;

   mpreal& operator-();
   mpreal& operator+=(const mpreal& a);
   mpreal& operator-=(const mpreal& a);
   mpreal& operator*=(const mpreal& a);
   mpreal& operator/=(const mpreal& a);

   friend ostream& operator<<(ostream& s, const mpreal& x);
};

// Derived Operations

inline mpreal operator+(const mpreal& a, const mpreal& b)
   {
   mpreal result = a;
   result += b;
   return result;
   }

inline mpreal operator-(const mpreal& a, const mpreal& b)
   {
   mpreal result = a;
   result -= b;
   return result;
   }

inline mpreal operator*(const mpreal& a, const mpreal& b)
   {
   mpreal result = a;
   result *= b;
   return result;
   }       
   
inline mpreal operator/(const mpreal& a, const mpreal& b)
   {
   mpreal result = a;
   result /= b;
   return result;
   }

#endif
