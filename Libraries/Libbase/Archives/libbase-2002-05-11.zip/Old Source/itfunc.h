#ifndef __itfunc_h
#define __itfunc_h

#include "config.h"
#include "vcs.h"
#include <math.h>
#include <stdlib.h>

/*
  Version 1.01 (6 Mar 2002)
  changed use of iostream from global to std namespace.

  Version 1.02 (17 Mar 2002)
  added function for rounding numbers.

  Version 1.03 (21 Apr 2002)
  added function for rounding numbers to specified resolution.
  also added alternative error function routines based on Chebychev fitting to an
  inspired guess as to the functional form (cf. Numerical Recipes in C, p.221).
*/
extern const vcs itfunc_version;

// gamma functions (cf. Numerical Recipes in C, p.216-219)
double gammln(const double xx);
double gammser(const double a, const double x);
double gammcf(const double a, const double x);
double gammp(const double a, const double x);

/*
   error function (cf. Numerical Recipes in C, p.220)
   erf(x) = 2/sqrt(pi) * integral from 0 to x of exp(-t^2) dt
   erfc(x) = 1-erf(x) = 2/sqrt(pi) * integral from x to inf of exp(-t^2) dt
*/
// based on Chebychev fitting - fractional error is everywhere less than 1.2E-7
double cerf(const double x);
double cerfc(const double x);
// based on incomplete Gamma functions - more accurate but much slower
inline double erff(const double x) { return x < 0.0 ? -gammp(0.5,x*x) : gammp(0.5,x*x); }
inline double erffc(const double x) { return x < 0.0 ? 1.0+gammp(0.5,x*x) : 1.0-gammp(0.5,x*x); }

inline double Q(const double x) { return 0.5 * erffc(x / sqrt(2.0)); }
inline double gauss(const double x) { return exp(-0.5 * x * x)/sqrt(2.0 * PI); }

inline double log2(const double x) { return log(x)/log(double(2)); }
inline int round(const double x) { return int(floor(x + 0.5)); }
inline double round(const double x, const double r) { return round(x/r)*r; }

int weight(const int cw);

int factorial(const int x);
int permutations(const int n, const int r);
inline int combinations(const int n, const int r) { return permutations(n,r)/factorial(r); }

double factoriald(const int x);
double permutationsd(const int n, const int r);
inline double combinationsd(const int n, const int r) { return permutationsd(n,r)/factoriald(r); }

#endif
