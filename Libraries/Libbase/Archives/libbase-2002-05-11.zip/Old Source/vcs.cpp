#include "vcs.h"

#include <iostream>
using namespace std;

const vcs vcs::version("Version Control System module (vcs)", 1.03);

vcs::vcs(const char *name, const double version, const char *build)
   {           
   int flags = clog.flags();
   clog.setf(ios::fixed, ios::floatfield);
   int prec = clog.precision(2);
   clog << "# VCS: " << name << " Version " << version << " (Build " << build << ")\n" << flush;
   clog.precision(prec);
   clog.flags(flags);
   }
