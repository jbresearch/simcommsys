#ifndef __config_h
#define __config_h

// Disable the "identifier truncated" warning in Win32
#ifdef WIN32
#   pragma warning ( disable : 4786 )
#endif

// Debugging tools (assert and trace; also includes standard streams)

#include <assert.h>
#include <iostream>
extern std::ostream trace;

// Names for integer types

typedef unsigned char	int8u;
typedef unsigned short	int16u;
typedef unsigned long	int32u;

typedef signed char     int8s;
typedef signed short    int16s;
typedef signed long		int32s;

// Common template functions

#ifdef min
#  undef min
#  undef max
#endif
template <class T> inline T min(const T a, const T b) { return( a<b ? a : b); };
template <class T> inline T max(const T a, const T b) { return( a>b ? a : b); };

#ifdef swap
#  undef swap
#endif
#ifndef WIN32
template <class T> inline void swap(T& a, T& b)
   {
   const T temp = a;
   a = b;
   b = temp;
   }
#endif

// Mathematical constants

extern const double PI;

// Directory deparator

#ifdef WIN32
#  define DIR_SEPARATOR '\\'
#else
#  define DIR_SEPARATOR '/'
#endif

// Define bool type if it does not exist

#if !defined(__GNUC__) && !defined(WIN32)
#define bool int
#define false 0
#define true 1
#endif

// Define math functions to identify NaN and Inf values

#ifdef WIN32
#include <float.h>

inline int isnan(double value) { return _isnan(value); };

inline int isinf(double value)
   {
   switch(_fpclass(value))
      {
      case _FPCLASS_NINF:
         return -1;
      case _FPCLASS_PINF:
         return +1;
      default:
         return 0;
      }
   }
#endif //ifdef WIN32


#ifdef sparc
extern "C" int getrusage(int who, struct rusage *usage);

#include <ieeefp.h>
inline int isinf(double value)
   {
   switch(fpclass(value))
      {
      case FP_NINF:
         return -1;
      case FP_PINF:
         return +1;
      default:
         return 0;
      }
   }
#endif // ifdef sparc


#ifdef __alpha__
#define clog cerr
#include <math.h>
#include <fp_class.h>
inline int isinf(double value)
   {
   switch(fp_class(value))
      {
      case FP_NEG_INF:
         return -1;
      case FP_POS_INF:
         return +1;
      default:
         return 0;
      }
   }
#endif // ifdef __alpha__


#endif
