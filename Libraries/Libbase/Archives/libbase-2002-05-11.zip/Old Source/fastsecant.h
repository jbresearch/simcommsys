#ifndef __fastsecant_h
#define __fastsecant_h

#include "config.h"
#include "vcs.h"
#include "secant.h"
#include "vector.h"

/*
  Version 1.00 (30 Nov 2001)
  speeded-up version of the secant method module - we build a cache on seeding
  which we then use to initialise the starting points for the algorithm.

  Version 1.01 (6 Mar 2002)
  changed vcs version variable from a global to a static class variable.
*/
class fastsecant : public secant {
   static const vcs version;
   vector<double> m_vdCache;
   double   m_dMin, m_dMax, m_dStep;
public:
   fastsecant(double (*func)(const double) = NULL);
   void seed(const double x1, const double x2, const int n);
   double solve(const double y);
   double operator()(const double y) { return solve(y); };
};

#endif

