#ifndef __vcs_h
#define __vcs_h

#include "config.h"

/*
  Version 1.01 (29 Oct 2001)
  redirected the output to clog instead of cout

  Version 1.02 (23 Feb 2002)
  added flushes to all end-of-line clog outputs, to clean up text user interface.

  Version 1.03 (6 Mar 2002)
  changed vcs version variable from a global to a static class variable.
  also changed use of iostream from global to std namespace.
*/
class vcs {
   static const vcs version;
public:
   vcs(const char *name, const double version, const char *build = __DATE__);
};

#endif

