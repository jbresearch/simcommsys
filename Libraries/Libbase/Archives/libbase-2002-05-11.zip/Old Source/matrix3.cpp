#include "matrix3.h"

const vcs matrix3_version("Generic 3D Matrix module (matrix3)", 1.60);
