#include "vector.h"

const vcs vector_version("Generic vector module (vector)", 1.61);

