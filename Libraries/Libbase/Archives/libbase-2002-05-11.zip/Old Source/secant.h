#ifndef __secant_h
#define __secant_h

#include "config.h"
#include "vcs.h"
#include <iostream>
using namespace std;

/*
  Version 1.01 (6 Mar 2002)
  changed vcs version variable from a global to a static class variable.
  also changed use of iostream from global to std namespace.
*/
class secant {
   static const vcs version;
   double	(*f)(const double);
   double	init_x1, init_x2, min_dx;
   int		max_iter;
public:
   secant(double (*func)(const double) = NULL);
   void bind(double (*func)(const double)) { f = func; };
   void seed(const double x1, const double x2);
   void accuracy(const double dx) { min_dx = dx; };
   void maxiter(const int n) { max_iter = n; };
   double solve(const double y);
   double operator()(const double y) { return solve(y); };
};

#endif

