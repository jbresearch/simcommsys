#include "serializer.h"
#include <iostream>
using namespace std;

//#define DEBUG

const vcs serializer::version("Serialization helper module (serializer)", 1.11);

// static variables

map<string,createfunc>* serializer::cmap = NULL;
int serializer::count = 0;

// static functions

void* serializer::call(const string& base, const string& derived)
   {
   createfunc func = (*cmap)[base+":"+derived];
#ifdef DEBUG
   clog << "DEBUG (serializer): call(" << base+":"+derived << ") = 0x" << hex << func << dec << ".\n";
#endif
   if(func == NULL)
      return NULL;
   return (*func)();
   }

// constructor / destructor

serializer::serializer(const string& base, const string& derived, createfunc func)
   {
   if(cmap == NULL)
      cmap = new map<string,createfunc>;
#ifdef DEBUG
   clog << "DEBUG (serializer): new map entry [" << count << "] for (" << base+":"+derived << ") = 0x" << hex << func << dec << ".\n";
#endif
   (*cmap)[base+":"+derived] = func;
   classname = derived;
   count++;
   }

serializer::~serializer()
   {
   count--;
   if(count == 0)
      delete cmap;
   }
