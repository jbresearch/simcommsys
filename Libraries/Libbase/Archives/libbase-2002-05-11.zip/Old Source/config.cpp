#include "config.h"

// Debugging tools

#ifdef WIN32
#   include <afx.h>
#endif

#include <ios>
#include <string>
using namespace std;

class tracestreambuf : public streambuf {
protected:
   string buffer;
public:
   tracestreambuf() { buffer = ""; };
   virtual ~tracestreambuf() {};
   int underflow() { return EOF; };
   int overflow(int c=EOF);
};

inline int tracestreambuf::overflow(int c)
   {
#ifndef NDEBUG
   if(c=='\r' || c=='\n')
      {
      if(!buffer.empty())
         {
#ifdef WIN32
         TRACE("%s\n", buffer.c_str());
#else
         clog << buffer.c_str() << endl << flush;
#endif
         buffer = "";
         }
      }
#ifdef WIN32
   // handle TRACE limit in Windows (512 chars including NULL)
   else if(buffer.length() == 511)
      {
      TRACE("%s", buffer.c_str());
      buffer = c;
      }
#endif
   else
      buffer += c;
#endif
   return 1;
   };

tracestreambuf g_tracebuf;
ostream trace(&g_tracebuf);

// Mathematical constants

const double PI = 3.14159265358979323846;

