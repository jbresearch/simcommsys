#ifndef __cmpi_h
#define __cmpi_h

#include "config.h"
#include "vcs.h"
#include "vector.h"

#ifdef MPI
#  include <mpi.h>
#endif

/*
  Version 1.01 (5 Mar 1999)
  updated mpi child functions to print the latency between jobs.

  Version 2.00 (23 Mar 1999)
  major update to the class.

  Version 2.10 (25 Mar 1999)
  changed the spawning algorithm. Now, this will spawn max*nodes processes, so that all processors
  are necessarily covered. Then, it will kill unnecessary nodes to avoid memory wastage. Note that
  with this technique, there is no more the need to have the nodes sorted in order of decreasing
  processors. Also, all nodes are cleanly in a single communicator, which aviods playing about with
  MPI. Also changed the initialisation process of children. Now children enter the loop immediately
  and must explicitly directed to send the number of processors to root or to get the size/rank.

  Version 2.11 (7 May 1999)
  re-schedules children with a lower priority to favour foreground tasks.

  Version 2.12 (22 Jul 1999)
  prints CPU usage information at the end of the process.

  Version 2.13 (3 Sep 1999)
  added functions for children to send integers to the root process

  Version 2.20 (29 Sep 2001)
  modified to compile on Win32 as a Dummy MPI module

  Version 2.21 (23 Feb 2002)
  added flushes to all end-of-line clog outputs, to clean up text user interface.

  Version 2.22 (6 Mar 2002)
  changed vcs version variable from a global to a static class variable.
  also changed use of iostream from global to std namespace.
*/
class cmpi {
   static const vcs version;

// constants
#ifdef MPI
private:
   static const int tag_base;
   static const int tag_data_doublevector;
   static const int tag_data_double;
   static const int tag_data_int;
   static const int tag_getname;
   static const int tag_getusage;
   static const int tag_getprocs;
   static const int tag_sizerank;
   static const int tag_work;
   static const int tag_die;
public:
   static const int root;
#endif

// static items
private:
   static bool initialised;
   static int mpi_nodes, mpi_rank, mpi_size;
#ifdef MPI
   static MPI_Comm child_comm; // inter-communicator for root <-> child processes
   static int *child_rank;     // an array mapping the virtual to real rank of child processes
   static int *child_rank_rev; // an array mapping the real to virtual rank of child processes
#endif
public:
   static void enable(int *argc, char **argv[], const int priority=10);
   static void disable();
   // informative functions
   static bool enabled() { return initialised; };
   static int nodes() { return mpi_nodes; };
   static int size() { return mpi_size; };
   static int rank() { return mpi_rank; };
   // parent communication functions
   static void _receive(double& x);
   static void _send(const int x);
   static void _send(const double x);
   static void _send(vector<double>& x);

// non-static items
public:
   // creation and destruction
   cmpi();
   ~cmpi();
   // child control functions
   void call(const int rank, void (*func)(void));
   // below: receive from any process; rank is updated to the originator
   void receive(int& rank, int& x);
   void receive(int& rank, double& x);
   void receive(int& rank, vector<double>& x);
   void send(const int rank, const double x);
};

#endif
