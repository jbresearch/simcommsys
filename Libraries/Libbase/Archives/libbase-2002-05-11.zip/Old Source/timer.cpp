#include "timer.h"
#include <math.h>

const vcs timer::version("Timer module (timer)", 1.35);

// system-dependent functions

#ifdef WIN32

double timer::wallclock() const
   {
   struct _timeb tb;
   
   _ftime(&tb);

   return convert(tb);
   }

double timer::cputime() const
   {
   return clock()/double(CLOCKS_PER_SEC);
   }

#else //(ifdef WIN32)

double timer::wallclock() const
   {
   struct timeval	  tv;
   struct timezone  tz;

   gettimeofday(&tv, &tz);

   return convert(tv);
   }
 
double timer::cputime() const
   {
   struct rusage	usage;
   double		cpu;

   getrusage(RUSAGE_SELF, &usage);
   cpu = convert(usage.ru_utime);
   getrusage(RUSAGE_CHILDREN, &usage);
   cpu += convert(usage.ru_utime);

   return(cpu);
   }

#endif //(ifdef WIN32)


// common functions

timer::timer(const char *n)
   {
   if(n == NULL)
      name = "";
   else
      name = n;
   start();
   }

timer::~timer()
   {
   if(running)
      {
      clog << "Timer";
      if(name != "")
         clog << " (" << name << ")";
      clog << " expired after " << *this << "\n" << flush;
      }
   }
   
void timer::start()
   {
   wall = wallclock();
   cpu = cputime();
   running = true;
   }  
   
void timer::stop()
   {
   if(!running)
      {
      cerr << "Warning: tried to stop a timer that was not running.\n";
      return;
      }
   wall = wallclock() - wall;
   cpu = cputime() - cpu;
   running = false;
   }
   
double timer::elapsed() const
   {
   if(running)
      return(wallclock() - wall);
   return wall;
   }

double timer::usage() const
   {
   double _wall, _cpu;

   if(running)
      {
      _wall = wallclock() - wall;
      _cpu = cputime() - cpu;
      }
   else
      {
      _wall = wall;
      _cpu = cpu;
      }
   return 100.0*_cpu/_wall;
   }

// static functions

string timer::format(const double elapsedtime)
   {
   const int max = 256;
   static char tempstring[max];

   if(elapsedtime < 60)
      {
      int order = int(ceil(-log10(elapsedtime)/3.0));
      if(order > 3)
         order = 3;
      sprintf(tempstring, "%0.2f", elapsedtime * pow(10, order*3));
      switch(order)
         {
         case 0:
            strcat(tempstring, "s");
            break;
         case 1:
            strcat(tempstring, "ms");
            break;
         case 2:
            strcat(tempstring, "us");
            break;
         case 3:
            strcat(tempstring, "ns");
            break;
         }
      }
   else
      {
      int  days, hrs, min, sec;

      sec = int(floor(elapsedtime));
      min = sec / 60;
      sec = sec % 60;
      hrs = min / 60;
      min = min % 60;
      days = hrs / 24;
      hrs = hrs % 24;
      if(days > 0)
         sprintf(tempstring, "%d %s, %02d:%02d:%02d", days, (days==1 ? "day" : "days"), hrs, min, sec);
      else
         sprintf(tempstring, "%02d:%02d:%02d", hrs, min, sec);
      }

   return tempstring;
   }

string timer::date()
   {
   const int max = 256;
   static char d[max];

   time_t t1 = time(NULL);
   struct tm *t2 = localtime(&t1);
   strftime(d, max, "%d %b %Y, %H:%M:%S", t2);

   return d;
   }

