#include "cmpi.h"

#include "timer.h"
#include <iostream>
using namespace std;

#ifdef MPI
#include <sys/time.h>
#include <sys/resource.h>
#endif

#ifndef MPI
const vcs cmpi::version("Dummy MPI Multi-Computer Environment module (cmpi)", 2.22);
#else
const vcs cmpi::version("LAM MPI Multi-Computer Environment module (cmpi)", 2.22);
#endif

// Constants

#ifdef MPI
const int cmpi::tag_base = 0;
const int cmpi::tag_data_doublevector = 0x01;
const int cmpi::tag_data_double = 0x02;
const int cmpi::tag_data_int = 0x03;
const int cmpi::tag_getname = 0xFA;
const int cmpi::tag_getusage = 0xFB;
const int cmpi::tag_getprocs = 0xFC;
const int cmpi::tag_sizerank = 0xFD;
const int cmpi::tag_work = 0xFE;
const int cmpi::tag_die = 0xFF;

const int cmpi::root = 0;
#endif

// Static items (initialised to a default value)

bool cmpi::initialised = false;
int cmpi::mpi_nodes = 0;
int cmpi::mpi_rank = -1;
int cmpi::mpi_size = -1;

#ifdef MPI
MPI_Comm cmpi::child_comm;
int *cmpi::child_rank;
int *cmpi::child_rank_rev;
#endif

// Static functions

void cmpi::enable(int *argc, char **argv[], const int priority)
   {
#ifndef MPI
   cerr << "FATAL ERROR (cmpi): MPI not implemented - cannot enable.\n";
   exit(1);
#else //(ifndef MPI)
   if(initialised)
      {
      cerr << "FATAL ERROR (cmpi): enable can only be called once.\n";
      exit(1);
      }
   // initialise the MPI routines
   initialised = true;
   MPI_Init(argc, argv);
   MPI_Status status;
   // if this was a spawned process, lock-in and wait for messages
   int parent;
   //MPI_Comm MPI_COMM_PARENT;
   //MPI_Comm_get_parent(&MPI_COMM_PARENT);
   MPI_Comm_remote_size(MPI_COMM_PARENT, &parent);
   if(parent != 0)
      {
      // Change the priority information as background task
      const int PRIO_CURRENT = 0;
      setpriority(PRIO_PROCESS, PRIO_CURRENT, priority);
      // Status information for user
      clog << "MPI child system starting (priority " << priority << ").\n" << flush;
      // get number of processors from an environment variable, default to 1
      char *cpus = getenv("CPUS");
      int procs = (cpus == NULL) ? 1 : atoi(cpus);
      // get hostname
      const int hostname_len = 32;
      char hostname[hostname_len];
      strncpy(hostname, getenv("HOSTNAME"), hostname_len);
      hostname[hostname_len-1] = 0;
      // infinite loop, until we are explicitly told to die
      timer tim1, tim2;
      // CPU usage timer
      tim2.start();
      while(true)
         {
         // Latency timer
         tim1.start();
         // Child working function prototype
         void (*func)(void);
         // Get the tag from Root
         MPI_Recv(&func, 1, MPI_LONG, MPI_ANY_SOURCE, MPI_ANY_TAG, MPI_COMM_PARENT, &status);
         // Status information for user
         clog << "MPI child (rank " << mpi_rank << "/" << mpi_size << ", latency = " << tim1 << "): ";
         // Work out the %age CPU time used
         int usage = int(tim2.usage());
         // Decide what should be done, based on the tag
         switch(status.MPI_TAG)
            {
            case tag_getname:
               // tell the root process our UNIX hostname
               MPI_Send(hostname, hostname_len, MPI_CHAR, root, tag_base, MPI_COMM_PARENT);
               clog << "send hostname [" << hostname << "]\n" << flush;
               break;
            case tag_getusage:
               // tell the root process how much CPU time we have used
               MPI_Send(&usage, 1, MPI_INT, root, tag_base, MPI_COMM_PARENT);
               clog << "send usage [CPU " << usage << "%]\n" << flush;
               break;
            case tag_getprocs:
               // tell the root process how many processors we have here
               MPI_Send(&procs, 1, MPI_INT, root, tag_base, MPI_COMM_PARENT);
               clog << "send processors [" << procs << "]\n" << flush;
               break;
            case tag_sizerank:
               // get from the root process our global rank and size
               MPI_Recv(&mpi_rank, 1, MPI_INT, root, tag_base, MPI_COMM_PARENT, &status);
               MPI_Recv(&mpi_size, 1, MPI_INT, root, tag_base, MPI_COMM_PARENT, &status);
               // Status information for user
               clog << "system initialised [rank " << mpi_rank << "/" << mpi_size << "]\n" << flush;
               break;
            case tag_work:
               clog << "system working\n" << flush;
               (*func)();
               break;
            case tag_die:
               clog << "system stopped\n" << flush;
               exit(0);
            default:
               clog << "received bad tag [" << status.MPI_TAG << "]\n" << flush;
               exit(1);
            }
         }
      }
   // Otherwise, this must be the parent process.
   clog << "MPI parent system initialised.\n" << flush;
   // set the number of nodes (get this from the underlying LAM process)
   int flag;
   int *attr_val;
   MPI_Attr_get(MPI_COMM_WORLD, MPI_UNIVERSE_SIZE, &attr_val, &flag);
   mpi_nodes = *attr_val;
   // spawn the first set of children - this is only to determine the number of processors
   clog << "MPI spawning " << mpi_nodes << " processes...\n" << flush;
   MPI_Spawn((*argv)[0], &(*argv)[1], mpi_nodes, MPI_INFO_NULL, root, MPI_COMM_SELF, &child_comm, NULL);
   // find out the largest number of processors in a node and the total number of processors
   int mpi_procs[mpi_nodes];
   int mpi_max = 1;
   mpi_size = 0;
   for(int i=0; i<mpi_nodes; i++)
      {
      // now for each node get the number of processors and kill the process
      MPI_Send(NULL, 0, MPI_LONG, i, tag_getprocs, child_comm);
      MPI_Recv(&mpi_procs[i], 1, MPI_INT, i, tag_base, child_comm, &status);
      MPI_Send(NULL, 0, MPI_LONG, i, tag_die, child_comm);
      // inform the user what is happening
      clog << "\tNode " << i << ":\t" << mpi_procs[i] << (mpi_procs[i]==1 ? " processor\n" : " processors\n") << flush;
      if(mpi_procs[i] > mpi_max)
         mpi_max = mpi_procs[i];
      mpi_size += mpi_procs[i];
      }
   clog << "\tTotal:\t" << mpi_size << " processors\n" << flush;
   // release communicator
   MPI_Comm_free(&child_comm);
   // spawn the set of children
   int mpi_nprocs = mpi_nodes*mpi_max;
   clog << "MPI spawning " << mpi_nprocs << " processes...\n" << flush;
   MPI_Spawn((*argv)[0], &(*argv)[1], mpi_nprocs, MPI_INFO_NULL, root, MPI_COMM_SELF, &child_comm, NULL);
   // kill unneeded processes and map the real rank to a virtual rank within the reduced set of processes
   child_rank = new int[mpi_size];
   child_rank_rev = new int[mpi_nprocs];
   int virt_rank = 0;
   for(int node=0; node<mpi_nodes; node++)
      {
      clog << "\tNode " << node << ":";
      for(int proc=0; proc<mpi_max; proc++)
         {
         int real_rank = proc * mpi_nodes + node;
         if(proc < mpi_procs[node])
            {
            clog << "\t[" << real_rank << "/" << virt_rank << "]";
            child_rank[virt_rank] = real_rank;
            child_rank_rev[real_rank] = virt_rank;
            virt_rank++;
            }
         else
            {
            clog << "\t[" << real_rank << "]";
            MPI_Send(NULL, 0, MPI_LONG, real_rank, tag_die, child_comm);
            }
         }
      clog << "\n" << flush;
      }
   // finally, it's time to tell all children their rank and the system's size
   for(int i=0; i<mpi_size; i++)
      {
      MPI_Send(NULL, 0, MPI_LONG, child_rank[i], tag_sizerank, child_comm);
      MPI_Send(&i, 1, MPI_INT, child_rank[i], tag_base, child_comm);
      MPI_Send(&mpi_size, 1, MPI_INT, child_rank[i], tag_base, child_comm);
      }
#endif //(ifndef MPI)
   }

void cmpi::disable()
   {
#ifdef MPI
   // print CPU usage information on the cluster and kill the children
   MPI_Status status;
   clog << "Processor Usage Summary:\n" << flush;
   int total = 0;
   for(int i=0; i<mpi_size; i++)
      {
      // now for each node get the number of processors and hostname; finally kill the process
      int usage;
      const int hostname_len = 32;
      char hostname[hostname_len];
      MPI_Send(NULL, 0, MPI_LONG, child_rank[i], tag_getusage, child_comm);
      MPI_Recv(&usage, 1, MPI_INT, child_rank[i], tag_base, child_comm, &status);
      MPI_Send(NULL, 0, MPI_LONG, child_rank[i], tag_getname, child_comm);
      MPI_Recv(hostname, hostname_len, MPI_CHAR, child_rank[i], tag_base, child_comm, &status);
      MPI_Send(NULL, 0, MPI_LONG, child_rank[i], tag_die, child_comm);
      total += usage;
      // inform the user what is happening
      clog << "\tCPU " << i << "\t(" << hostname << "):\t" << usage << "%\n" << flush;
      }
   clog << "\tTotal:\t" << total << "%\n" << flush;
   // deallocate memory
   delete[] child_rank;
   delete[] child_rank_rev;
   // release communicator
   MPI_Comm_free(&child_comm);
   // cease MPI operations
   initialised = false;
   MPI_Finalize();
#endif //(ifdef MPI)
   }


// functions for children to communicate with their parent (the root node)

void cmpi::_receive(double& x)
   {
#ifdef MPI
   // allocate temporary storage
   double a;
   // receive
   MPI_Status status;
   MPI_Recv(&a, 1, MPI_DOUBLE, root, tag_data_double, MPI_COMM_PARENT, &status);
   // fill in results
   x = a;
#endif //(ifdef MPI)
   }

void cmpi::_send(const int x)
   {
#ifdef MPI
   // allocate temporary storage
   int a = x;
   // send
   MPI_Send(&a, 1, MPI_INT, root, tag_data_int, MPI_COMM_PARENT);
#endif //(ifdef MPI)
   }

void cmpi::_send(const double x)
   {
#ifdef MPI
   // allocate temporary storage
   double a = x;
   // send
   MPI_Send(&a, 1, MPI_DOUBLE, root, tag_data_double, MPI_COMM_PARENT);
#endif //(ifdef MPI)
   }

void cmpi::_send(vector<double>& x)
   {
#ifdef MPI
   // allocate temporary storage
   const int count = x.size();
   double a[count];
   // fill in the array
   for(int i=0; i<count; i++)
      a[i] = x(i);
   // send
   MPI_Send(a, count, MPI_DOUBLE, root, tag_data_doublevector, MPI_COMM_PARENT);
#endif //(ifdef MPI)
   }

// Non-static items

cmpi::cmpi()
   {
   // only need to do this check here, on creation. If the cmpi object
   // is created, then MPI must be running.
   if(!initialised)
      {
      cerr << "FATAL ERROR (cmpi): MPI not initialised.\n";
      exit(1);
      }
   }

cmpi::~cmpi()
   {
   }

// child control function (make a child call a given function)

void cmpi::call(const int rank, void (*func)(void))
   {
#ifdef MPI
   long addr = (long)func;
   MPI_Send(&addr, 1, MPI_LONG, child_rank[rank], tag_work, child_comm);
#endif //(ifdef MPI)
   }

// functions for communicating with child

void cmpi::receive(int& rank, int& x)
   {
#ifdef MPI
   // allocate temporary storage
   int a;
   // receive
   MPI_Status status;
   MPI_Recv(&a, 1, MPI_INT, MPI_ANY_SOURCE, tag_data_int, child_comm, &status);
   // fill in results
   x = a;
   rank = child_rank_rev[status.MPI_SOURCE];
#endif //(ifdef MPI)
   }

void cmpi::receive(int& rank, double& x)
   {
#ifdef MPI
   // allocate temporary storage
   double a;
   // receive
   MPI_Status status;
   MPI_Recv(&a, 1, MPI_DOUBLE, MPI_ANY_SOURCE, tag_data_double, child_comm, &status);
   // fill in results
   x = a;
   rank = child_rank_rev[status.MPI_SOURCE];
#endif //(ifdef MPI)
   }

void cmpi::receive(int& rank, vector<double>& x)
   {
#ifdef MPI
   // allocate temporary storage
   const int count = x.size();
   double a[count];
   // receive
   MPI_Status status;
   MPI_Recv(a, count, MPI_DOUBLE, MPI_ANY_SOURCE, tag_data_doublevector, child_comm, &status);
   // fill in results
   for(int i=0; i<count; i++)
      x(i) = a[i];
   rank = child_rank_rev[status.MPI_SOURCE];
#endif //(ifdef MPI)
   }

void cmpi::send(const int rank, const double x)
   {
#ifdef MPI
   // allocate temporary storage
   double a = x;
   // send
   MPI_Send(&a, 1, MPI_DOUBLE, child_rank[rank], tag_data_double, child_comm);
#endif //(ifdef MPI)
   }
