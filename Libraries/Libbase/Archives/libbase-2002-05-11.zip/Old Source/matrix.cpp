#include "matrix.h"

const vcs matrix_version("Generic 2D Matrix module (matrix)", 1.62);

