#include "pixel.h"

namespace libimage {

const libbase::vcs pixel::version("True Colour Pixel module (pixel)", 1.10);

}; // end namespace
