#include "experiment.h"

const vcs experiment::version("Generic experiment module (experiment)", 1.12);

