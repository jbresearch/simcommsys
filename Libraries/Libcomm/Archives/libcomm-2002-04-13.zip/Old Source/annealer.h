#ifndef __annealer_h
#define __annealer_h

#include "config.h"
#include "vcs.h"
#include "anneal_system.h"
#include "randgen.h"
#include "rvstatistics.h"

/*
  Version 1.01 (10 Oct 2001)
  added a virtual display function, to facilitate deriving from the class to produce a
  windowed GUI (by using custom display routines), and also added a virtual interrupt
  function to allow a derived class to stop the processing routine. Both functions are
  protected so they can only be called by the class itself or by derived classes.

  Version 1.02 (16 Nov 2001)
  added a virtual destructor.

  Version 1.03 (23 Feb 2002)
  added flushes to all end-of-line clog outputs, to clean up text user interface.

  Version 1.04 (6 Mar 2002)
  changed vcs version variable from a global to a static class variable.
  also changed use of iostream from global to std namespace.
*/
class annealer {
   static const vcs version;
protected:
   anneal_system *system;
   randgen  r;
   double   Tstart, Tstop, rate;
   int      min_iter, min_changes;
protected:
   virtual ~annealer() {};
   virtual bool interrupt() { return false; };
	virtual void display(const double T, const double percent, const rvstatistics E);
public:
   void attach_system(anneal_system& system);
   void seed(const int s);
   void set_temperature(const double Tstart, const double Tstop);
   void set_schedule(const double rate);
   void set_iterations(const int min_iter, const int min_changes);
   void improve();
};

#endif
