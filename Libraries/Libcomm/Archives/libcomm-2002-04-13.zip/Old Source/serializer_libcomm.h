#ifndef __serializer_libcomm_h
#define __serializer_libcomm_h

// Channels
#include "channel.h"
#include "awgn.h"
#include "laplacian.h"

// Modulators
#include "modulator.h"
#include "mpsk.h"

// Convolutional Encoders
#include "fsm.h"
#include "nrcc.h"
#include "rscc.h"

// Interleavers
#include "interleaver.h"
#include "onetimepad.h"
#include "padded.h"
// LUT Interleavers
#include "lut_interleaver.h"
#include "berrou.h"
#include "flat.h"
#include "helical.h"
#include "rand_lut.h"
#include "rectangular.h"
#include "shift_lut.h"
#include "uniform_lut.h"
// Named LUT
#include "named_lut.h"
#include "file_lut.h"
#include "stream_lut.h"
#include "vale96int.h"

// Codecs
#include "codec.h"
#include "uncoded.h"
#include "mapcc.h"
#include "turbo.h"
#include "diffturbo.h"

// Puncture Patterns
#include "puncture.h"
#include "puncture_file.h"
#include "puncture_null.h"
#include "puncture_stipple.h"


// Arithmetic Types
#include "mpgnu.h"
#include "mpreal.h"
#include "logreal.h"
#include "logrealfast.h"


// Serialization support
class serializer_libcomm : private
   awgn, laplacian,
   mpsk,
   nrcc, rscc,
   onetimepad, padded, berrou, flat, helical, rand_lut, rectangular, shift_lut, uniform_lut, named_lut,
   uncoded, mapcc<logrealfast>, /*turbo<logrealfast>,*/ diffturbo<logrealfast>,
   puncture_file, puncture_null, puncture_stipple
{
public:
   serializer_libcomm() {};
};


#endif
