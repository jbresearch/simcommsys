#include "anneal_system.h"

const vcs anneal_system::version("Simulated Annealing System Base module (anneal_system)", 1.21);

ostream& operator<<(ostream& sout, const anneal_system& x)
   {
   return x.output(sout);
   }

