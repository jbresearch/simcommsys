#ifndef __modulator_h
#define __modulator_h
      
#include "config.h"
#include "vcs.h"
#include "sigspace.h"
#include "itfunc.h"
#include "vector.h"
#include "matrix.h"
#include "channel.h"
#include <iostream>
#include <string>
using namespace std;

/*
  Version 1.01 (26 Oct 2001)
  added a virtual destroy function (see interleaver.h)

  Version 1.02 (6 Mar 2002)
  changed vcs version variable from a global to a static class variable.
  also changed use of iostream from global to std namespace.

  Version 1.10 (13 Mar 2002)
  added a virtual function which outputs details on the modulator, together with a stream
  << operator too. Also added serialization facility. Created serialize and stream << and
  >> functions to conform with the new serializer protocol, as defined in serializer 1.10.
  The stream << output function first writes the name of the derived class, then calls its
  serialize() to output the data. The name is obtained from the virtual name() function.
  The stream >> input function first gets the name from the stream, then (via
  serialize::call) creates a new object of the appropriate type and calls its serialize()
  function to get the relevant data. Also added cloning function.

  Version 1.20 (17 Mar 2002)
  added functions to modulate a vector of encoded symbols and demodulate a vector of
  sigspace symbols (given a channel model), and new names for the functions that modulate
  or demodulate single elements (the operator[] functions are now just alternative
  notations). Also modified the information-returning functions to return non-const,
  since this won't make any difference.

  Version 1.30 (27 Mar 2002)
  removed the descriptive output() and related stream << output functions, and replaced
  them by a function description() which returns a string. This provides the same
  functionality but in a different format, so that now the only stream << output
  functions are for serialization. This should make the notation much clearer while
  also simplifying description display in objects other than streams.

  Version 1.31 (27 Mar 2002)
  changed the way we store the array of modulation symbols from a heap-allocated
  array to a vector; this significantly simplifies the memory management. Also,
  removed the member variable M, since the number of symbols is easily obtained from
  the vector. Also changed modulate() and operator[] to return sigspace object directly
  not by reference (should have been this way before since the functions are const).
*/
class modulator {
   static const vcs version;
protected:
   vector<sigspace> map; // Array of modulation symbols
public:
   virtual ~modulator() {};               // virtual destructor
   virtual modulator *clone() const = 0;	// cloning operation
   virtual const char* name() const = 0;  // derived object's name

   // modulation/demodulation - atomic operations
   const sigspace modulate(const int index) const { return map(index); };
   const int demodulate(const sigspace& signal) const;
   const sigspace operator[](const int index) const { return modulate(index); };
   const int operator[](const sigspace& signal) const { return demodulate(signal); };

   // modulation/demodulation - vector operations
   //    N - the number of possible values of each encoded element
   void modulate(const int N, const vector<int>& encoded, vector<sigspace>& tx) const;
   void demodulate(const channel& chan, const vector<sigspace>& rx, matrix<double>& ptable) const;

   // information functions
   int num_symbols() const { return map.size(); };
   double energy() const;                                   // average energy per symbol
   double bit_energy() const { return energy()/log2(map.size()); };  // average energy per bit

   // description output
   virtual string description() const = 0;
   // object serialization - saving
   virtual ostream& serialize(ostream& sout) const = 0;
   friend ostream& operator<<(ostream& sout, const modulator* x);
   // object serialization - loading
   virtual istream& serialize(istream& sin) = 0;
   friend istream& operator>>(istream& sin, modulator*& x);
};

#endif
