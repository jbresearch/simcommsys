#ifndef __montecarlo_h
#define __montecarlo_h

#include "config.h"
#include "vcs.h"

#include "experiment.h"

/*
  Version 1.10 (2 Sep 1999)
  added a hook for clients to know the number of frames simulated in a particular run.

  Version 1.11 (9 Sep 1999)
  changed min_passes to 128, since we observed that with 30 samples only, the distribution
  is still quite skewed.

  Version 1.12 (26 Oct 2001)
  added a virtual display function, to facilitate deriving from the class to produce a
  windowed GUI (by using custom display routines), and also added a virtual interrupt
  function to allow a derived class to stop the processing routine. Both functions are
  protected so they can only be called by the class itself or by derived classes.

  Version 1.13 (26 Oct 2001)
  added an empty creator object which doesn't initialise the simulator and doesn't bind
  it to a system - this is necessary for deriving classes from this. Also created separate
  initialisation and finalisation routines to allow re-use of the same montecarlo object.

  Version 1.14 (16 Nov 2001)
  added a virtual destructor.

  Version 1.15 (23 Feb 2002)
  added flushes to all end-of-line clog outputs, to clean up text user interface.

  Version 1.16 (6 Mar 2002)
  changed vcs version variable from a global to a static class variable.
  also changed use of iostream from global to std namespace.

  Version 1.17 (25 Mar 2002)
  changed min_passes to min_samples, to indicate that this is the number of minimum
  samples, not of minimum cycles, that are necessary to ensure a gaussian distribution.
  Note that in each pass, there will really be a number of samples, depending on how
  long each sample takes.

  Version 1.18 (27 Mar 2002)
  removed the timer display on clog for the estimate function.
*/
class montecarlo {
   static const vcs version;
   // bound objects
   static bool init;
   static experiment *system;
   // internal variables
   static const int	min_samples;	// minimum number of samples to assume gaussian distribution
   int      max_passes; // max # of passes (with 1 non-zero result) affecting acceptance
   double   cfactor;	// factor dependent on confidence level
   double   accuracy;	// accuracy level required
   int      samplecount;      // number of samples taken to produce the result (updated by experiment module to allow for dynamic sampling)
   // MPI child process
   static void child_init(void);
   static void child_work(void);
protected:
   virtual bool interrupt() { return false; };
   virtual void display(const int pass, const double cur_accuracy, const double cur_mean);
public:
   montecarlo(experiment *system);
   montecarlo();
   virtual ~montecarlo();
   
   void initialise(experiment *system);
   void finalise();

   void set_confidence(const double confidence);   // say, 0.95 => 95% probability
   void set_accuracy(const double accuracy);	   // say, 0.10 => 10% of mean
   void set_bailout(const int passes);             // say, 1000 => at least 1 in 1000 non-zero estimates (0 to disable)
   
   int get_samplecount() { return samplecount; };  // returns the number of samples taken to produce the result
   void estimate(vector<double>& result, vector<double>& tolerance);		// get an estimate with given accuracy & confidence
};

#endif
