#include "flat.h"
#include <stdlib.h>
#include <sstream>
using namespace std;

const vcs flat::version("Flat Interleaver module (flat)", 1.30);

const serializer flat::shelper("interleaver", "flat", flat::create);

// initialization

void flat::init(const int tau)
   {
   lut.init(tau);
   for(int i=0; i<tau; i++)
      lut(i) = i;
   }

// description output

string flat::description() const
   {
   ostringstream sout;
   sout << "Flat Interleaver";
   return sout.str();
   }

// object serialization - saving

ostream& flat::serialize(ostream& sout) const
   {
   sout << lut.size() << "\n";
   return sout;
   }

// object serialization - loading

istream& flat::serialize(istream& sin)
   {
   int tau;
   sin >> tau;
   init(tau);
   return sin;
   }
