#include "puncture_null.h"

const vcs puncture_null::version("Null Puncturing System module (puncture_null)", 2.20);

const serializer puncture_null::shelper("puncture", "null", puncture_null::create);


// initialization

void puncture_null::init(const int tau)
   {
   // initialise the pattern matrix
   matrix<bool> pattern(tau,1);
   pattern = 1;
   // fill-in remaining variables
   puncture::init(pattern);
   }

// description output

string puncture_null::description() const
   {
   return "Unpunctured";
   }

// object serialization - saving

ostream& puncture_null::serialize(ostream& sout) const
   {
   sout << get_inputs() << "\n";
   return sout;
   }

// object serialization - loading

istream& puncture_null::serialize(istream& sin)
   {
   int tau;
   sin >> tau;
   init(tau);
   return sin;
   }
