#include "padded.h"
#include <sstream>
using namespace std;

const vcs padded::version("Padded Interleaver module (padded)", 1.40);

const serializer padded::shelper("interleaver", "padded", padded::create);


// construction and destruction

padded::padded()
   {
   otp = NULL;
   inter = NULL;
   }

padded::padded(const interleaver& inter, const fsm& encoder, const int tau, const bool terminated, const bool renewable)
   {
   otp = new onetimepad(encoder, tau, terminated, renewable);
   padded::inter = inter.clone();
   }

padded::padded(const padded& x)
   {
   inter = x.inter->clone();
   otp = x.otp->clone();
   }

padded::~padded()
   {
   if(otp != NULL)
      delete otp;
   if(inter != NULL)
      delete inter;
   }

// inter-frame operations

void padded::seed(const int s)
   {
   otp->seed(s);
   }

void padded::advance()
   {
   otp->advance();
   }

// transform functions

void padded::transform(vector<int>& in, vector<int>& out) const
   {
   vector<int> temp(in.size());
   inter->transform(in, temp);
   otp->transform(temp, out);
   }

void padded::transform(matrix<double>& in, matrix<double>& out) const
   {
   matrix<double> temp(in.xsize(), in.ysize());
   inter->transform(in, temp);
   otp->transform(temp, out);
   }

void padded::inverse(matrix<double>& in, matrix<double>& out) const
   {
   matrix<double> temp(in.xsize(), in.ysize());
   otp->inverse(in, temp);
   inter->inverse(temp, out);
   }

// description output

string padded::description() const
   {
   ostringstream sout;
   sout << "Padded Interleaver [" << inter->description() << " + " << otp->description() << "]";
   return sout.str();
   }

// object serialization - saving

ostream& padded::serialize(ostream& sout) const
   {
   sout << otp;
   sout << inter;
   return sout;
   }

// object serialization - loading

istream& padded::serialize(istream& sin)
   {
   sin >> otp;
   sin >> inter;
   return sin;
   }
