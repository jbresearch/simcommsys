#ifndef __named_lut_h
#define __named_lut_h

#include "config.h"
#include "vcs.h"
#include "lut_interleaver.h"
#include "serializer.h"
#include <string>
#include <iostream>
using namespace std;

/*
  Version 1.00 (13 Mar 2002)
  original version. Intended as a base class to implement any interleaver which is
  specified directly by its LUT, which is externally generated (say by Simulated Annealing
  or another such method), and has a name associated with it. This version was adapted
  from file_lut 1.32, and supports forced tails. Derivative classes only need to provide
  their own constructors and destructors, as necessary.

  Version 1.10 (27 Mar 2002)
  changed descriptive output function to conform with interleaver 1.40.
*/
class named_lut : public lut_interleaver {
   static const vcs version;
   static const serializer shelper;
   static void* create() { return new named_lut; };
protected:
   string lutname;
   int m;
   named_lut() {};
public:
   interleaver* clone() const { return new named_lut(*this); };
   const char* name() const { return shelper.name(); };

   string description() const;
   ostream& serialize(ostream& sout) const;
   istream& serialize(istream& sin);
};

#endif

