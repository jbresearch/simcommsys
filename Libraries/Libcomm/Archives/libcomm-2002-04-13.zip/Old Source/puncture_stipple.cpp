#include "puncture_stipple.h"
#include <sstream>
using namespace std;

const vcs puncture_stipple::version("Stippled Puncturing System module (puncture_stipple)", 2.20);

const serializer puncture_stipple::shelper("puncture", "stipple", puncture_stipple::create);


// initialization

void puncture_stipple::init(const int tau, const int sets)
   {
   puncture_stipple::tau = tau;
   puncture_stipple::sets = sets;
   // initialise the pattern matrix
   matrix<bool> pattern(tau,sets);
   for(int t=0; t<tau; t++)
      for(int s=0; s<sets; s++)
         pattern(t,s) = (s==0 || (s-1)==t%(sets-1));
   // fill-in remaining variables
   puncture::init(pattern);
   }

// description output

string puncture_stipple::description() const
   {
   ostringstream sout;
   sout << "Stipple Puncturing (" << tau << "x" << sets << ", " << get_outputs() << "/" << get_inputs() << ")";
   return sout.str();
   }

// object serialization - saving

ostream& puncture_stipple::serialize(ostream& sout) const
   {
   sout << tau << "\n";
   sout << sets << "\n";
   return sout;
   }

// object serialization - loading

istream& puncture_stipple::serialize(istream& sin)
   {
   sin >> tau >> sets;
   init(tau, sets);
   return sin;
   }
