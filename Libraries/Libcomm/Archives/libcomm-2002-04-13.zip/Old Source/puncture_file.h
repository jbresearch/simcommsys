#ifndef __puncture_file_h
#define __puncture_file_h

#include "config.h"
#include "vcs.h"
#include "puncture.h"
#include "serializer.h"
#include <string>
using namespace std;

/*
  Version 1.00 (7 Jun 1999)
  initial version, implementing a puncturing pattern read from file.

  Version 1.01 (4 Nov 2001)
  added a function which outputs details on the puncturing scheme (in accordance 
  with puncture 1.10)

  Version 1.02 (6 Mar 2002)
  changed vcs version variable from a global to a static class variable.
  also changed use of iostream from global to std namespace.

  Version 1.10 (13 Mar 2002)
  updated the system to conform with the completed serialization protocol (in conformance
  with puncture 1.20), by adding the necessary name() function, and also by adding a static
  serializer member and initialize it with this class's name and the static constructor
  (adding that too, together with the necessary protected default constructor). Also made
  the puncture object a public base class, rather than a virtual public one, since this
  was affecting the transfer of virtual functions within the class (causing access
  violations).

  Version 2.00 (18 Mar 2002)
  updated to conform with puncture 2.00.

  Version 2.10 (27 Mar 2002)
  changed descriptive output function to conform with puncture 2.10.

  Version 2.20 (27 Mar 2002)
  updated to conform with puncture 2.20.
*/
class puncture_file : public puncture {
   static const vcs version;
   static const serializer shelper;
   static void* create() { return new puncture_file; };
private:
   matrix<bool> pattern;
protected:
   string filename;
   puncture_file() {};
public:
   puncture_file(const char *fname, const int tau, const int sets);
   ~puncture_file() {};

   puncture *clone() const { return new puncture_file(*this); };		// cloning operation
   const char* name() const { return shelper.name(); };

   string description() const;
   ostream& serialize(ostream& sout) const;
   istream& serialize(istream& sin);
};

#endif
