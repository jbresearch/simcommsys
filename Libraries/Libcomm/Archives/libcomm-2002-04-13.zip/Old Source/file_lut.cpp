#include "file_lut.h"
#include <stdio.h>

const vcs file_lut::version("Pre-stored LUT Interleaver module (file_lut)", 1.33);


// creation/destruction functions

file_lut::file_lut(const char *filename, const int tau, const int m)
   {
   file_lut::m = m;

   const char *s = strrchr(filename, DIR_SEPARATOR);
   const char *p = (s==NULL) ? filename : s+1;
   lutname = p;

   lut.init(tau);

   char buf[256];
   FILE *file = fopen(filename, "rb");
   if(file == NULL)
      {
      cerr << "FATAL ERROR (file_lut): Cannot open LUT file (" << filename << ").\n";
      exit(1);
      }
   for(int i=0; i<tau-m; i++)
      {
      do {
         fscanf(file, "%[^\n]\n", buf);
         } while(buf[0] == '#');
      int x, y;
      sscanf(buf, "%d%d", &x, &y);
      if(x != i)
         {
         cerr << "FATAL ERROR (file_lut): unexpected entry for line " << i << ": " << x << ", " << y << "\n";
         exit(1);
         }
      lut(i) = y;
      }
   for(int t=tau-m; t<tau; t++)
      lut(t) = tail;
   fclose(file);
   }
