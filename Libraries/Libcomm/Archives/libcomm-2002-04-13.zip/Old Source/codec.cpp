#include "codec.h"
#include "serializer.h"

const vcs codec::version("Channel Codec Base module (codec)", 1.50);


// serialization functions

ostream& operator<<(ostream& sout, const codec* x)
   {
   sout << x->name() << "\n";
   x->serialize(sout);
   return sout;
   }

istream& operator>>(istream& sin, codec*& x)
   {
   string name;
   sin >> name;
   x = (codec*) serializer::call("codec", name);
   if(x == NULL)
      {
      cerr << "FATAL ERROR (codec): Type \"" << name << "\" unknown.\n";
      exit(1);
      }
   x->serialize(sin);
   return sin;
   }
