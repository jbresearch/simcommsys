#include "sigspace.h"

const vcs sigspace::version("Signal Space module (sigspace)", 1.10);


// creator / destructor

sigspace::sigspace(const double i, const double q)
   {
   inphase = i;
   quad = q;
   }   

// arithmetic operations

sigspace& sigspace::operator+=(const sigspace& a)
   {
   inphase += a.inphase;
   quad += a.quad;
   return *this;
   }

sigspace& sigspace::operator-=(const sigspace& a)
   {
   inphase -= a.inphase;
   quad -= a.quad;
   return *this;
   }

sigspace& sigspace::operator*=(const double a)
   {
   inphase *= a;
   quad *= a;
   return *this;
   }

sigspace& sigspace::operator/=(const double a)
   {
   inphase /= a;
   quad /= a;
   return *this;
   }

// arithmetic operations - friends

sigspace operator+(const sigspace& a, const sigspace& b)
   {
   sigspace c = a;
   c += b;
   return c;
   }
   
sigspace operator-(const sigspace& a, const sigspace& b)
   {
   sigspace c = a;
   c -= b;
   return c;
   }
   
sigspace operator*(const sigspace& a, const double b)
   {
   sigspace c = a;
   c *= b;
   return c;
   }
   
sigspace operator/(const sigspace& a, const double b)
   {
   sigspace c = a;
   c /= b;
   return c;
   }

sigspace operator*(const double a, const sigspace& b)
   {
   sigspace c = b;
   c *= a;
   return c;
   }
   
sigspace operator/(const double a, const sigspace& b)
   {
   sigspace c = b;
   c /= a;
   return c;
   }

// stream input / output

ostream& operator<<(ostream& s, const sigspace& x)
   {
   s.setf(ios::fixed, ios::floatfield);
   s.precision(6);
   s << '[' << x.inphase << ',';
   s.setf(ios::fixed, ios::floatfield);
   s.precision(6);
   s << x.quad << ']';
   return s;
   }
   
istream& operator>>(istream& s, sigspace& x)
   {
   double i = 0, q = 0;
   char c = 0;
   
   s >> c;
   if(c == '[')
      {
      s >> i >> c;
      if(c == ',')
         s >> q >> c;
      else
         s.clear(ios::badbit);
      if(c != ']')
         s.clear(ios::badbit);
      }
   else
      s.clear(ios::badbit);
   
   if(s)
      x = sigspace(i, q);
      
   return s;
   }


