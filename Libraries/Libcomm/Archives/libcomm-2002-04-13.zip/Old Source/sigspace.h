#ifndef __sigspace_h
#define __sigspace_h
      
#include "config.h"
#include "vcs.h"
#include <math.h>
#include <iostream>
using namespace std;

/*
  Version 1.01 (6 Mar 2002)
  changed vcs version variable from a global to a static class variable.
  also changed use of iostream from global to std namespace.

  Version 1.02 (13 Mar 2002)
  moved most functions to the implementation file instead of here.

  Version 1.10 (27 Mar 2002)
  added two functions to make multiplication with double commutative. Also, made
  passing of all double parameters direct, not by reference.
*/
class sigspace {
   static const vcs version;
   double	inphase, quad;
public:
   sigspace(const double i=0, const double q=0);

   double i() const { return inphase; };
   double q() const { return quad; };
   double r() const { return sqrt(i()*i() + q()*q()); };
   double p() const { return atan2(q(), i()); };
   operator double() const { return r(); };

   sigspace& operator+=(const sigspace& a);
   sigspace& operator-=(const sigspace& a);
   sigspace& operator*=(const double a);
   sigspace& operator/=(const double a);
   friend sigspace operator+(const sigspace& a, const sigspace& b);
   friend sigspace operator-(const sigspace& a, const sigspace& b);
   friend sigspace operator*(const sigspace& a, const double b);
   friend sigspace operator/(const sigspace& a, const double b);
   friend sigspace operator*(const double a, const sigspace& b);
   friend sigspace operator/(const double a, const sigspace& b);

   friend ostream& operator<<(ostream& s, const sigspace& x);
   friend istream& operator>>(istream& s, sigspace& x);
};

#endif
