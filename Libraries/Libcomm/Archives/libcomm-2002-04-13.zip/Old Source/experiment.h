#ifndef __experiment_h
#define __experiment_h

#include "config.h"
#include "vcs.h"
#include "vector.h"

/*
  Version 1.10 (2 Sep 1999)
  added a hook for clients to know the number of frames simulated in a particular run.

  Version 1.11 (26 Oct 2001)
  added a virtual destroy function (see interleaver.h)

  Version 1.12 (6 Mar 2002)
  changed vcs version variable from a global to a static class variable.
*/
class experiment {
   static const vcs version;
public:
   virtual ~experiment() {};
   virtual int count() const = 0;
   virtual void seed(int s) = 0;
   virtual void set(double x) = 0;
   virtual double get() = 0;
   virtual void sample(vector<double>& result, int& samplecount) = 0;
};

#endif
