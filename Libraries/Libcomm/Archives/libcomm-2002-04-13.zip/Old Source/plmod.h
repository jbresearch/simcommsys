#ifndef __plmod_h
#define __plmod_h

#include "config.h"

double plmod(const double u);

#endif
