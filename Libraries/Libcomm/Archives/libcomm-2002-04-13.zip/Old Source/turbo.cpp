#include "turbo.h"
#include <sstream>
using namespace std;


// initialization / de-allocation

template <class real> void turbo<real>::init()
   {
   bcjr<real>::init(*encoder, tau, true, endatzero);

   m = endatzero ? encoder->mem_order() : 0;
   M = encoder->num_states();
   K = encoder->num_inputs();
   N = encoder->num_outputs();
   P = N/K;		// this *must* be an integer (for any binary code, at least)

   seed(0);
   initialised = false;
   }

template <class real> void turbo<real>::free()
   {
   if(encoder != NULL)
      delete encoder;
   for(int i=0; i<inter.size(); i++)
      delete inter(i);
   }

// constructor / destructor

template <class real> turbo<real>::turbo()
   {
   encoder = NULL;
   }

template <class real> turbo<real>::turbo(const fsm& encoder, const int tau, \
   const vector<interleaver *>& inter, const int iter, const bool simile, \
   const bool endatzero, const bool parallel)
   {
   turbo::encoder = encoder.clone();
   turbo::tau = tau;
   turbo::sets = inter.size()+1;
   turbo::inter = inter;
   turbo::simile = simile;
   turbo::endatzero = endatzero;
   turbo::parallel = parallel;
   turbo::iter = iter;
   init();
   }

// memory allocator (for internal use only)

template <class real> void turbo<real>::allocate()
   {
   r.init(sets);
   R.init(sets);
   for(int i=0; i<sets; i++)
      {
      r(i).init(tau, K);
      R(i).init(tau, N);
      }

   ri.init(tau, K);
   rai.init(tau, K);
   rii.init(tau, K);

   if(parallel)
      {
      ra.init(sets);
      for(int i=0; i<sets; i++)
         ra(i).init(tau, K);
      }
   else
      {
      ra.init(1);
      ra(0).init(tau, K);
      }

   initialised = true;
   }

// wrapping functions

template <class real> void turbo<real>::work_extrinsic(matrix<double>& ra, matrix<double>& ri, matrix<double>& r, matrix<double>& re)
   {
   // calculate extrinsic information
   for(int t=0; t<tau; t++)
      for(int x=0; x<K; x++)
         re(t, x) = ri(t, x) / (ra(t, x) * r(t, x));
   }

template <class real> void turbo<real>::bcjr_wrap(const int set, matrix<double>& ra, matrix<double>& ri, matrix<double>& re)
   {
   // pass through BCJR algorithm
   // interleaving and de-interleaving is performed except for the first set
   if(set == 0)
      {
      bcjr<real>::fdecode(R(set), ra, ri);
      work_extrinsic(ra, ri, r(set), re);
      }
   else
      {
      inter(set-1)->transform(ra, rai);
      bcjr<real>::fdecode(R(set), rai, rii);
      work_extrinsic(rai, rii, r(set), rai);
      inter(set-1)->inverse(rii, ri);
      inter(set-1)->inverse(rai, re);
      }
   }

template <class real> void turbo<real>::hard_decision(matrix<double>& ri, vector<int>& decoded)
   {
   // Decide which input sequence was most probable.
   for(int t=0; t<tau; t++)
      {
      decoded(t) = 0;
      for(int i=1; i<K; i++)
         if(ri(t, i) > ri(t, decoded(t)))
            decoded(t) = i;
      }
   }

template <class real> void turbo<real>::decode_serial(matrix<double>& ri)
   {
   // after working all sets, ri is the intrinsic+extrinsic information
   // from the last stage decoder.
   for(int set=0; set<sets; set++)
      bcjr_wrap(set, ra(0), ri, ra(0));
   }

template <class real> void turbo<real>::decode_parallel(matrix<double>& ri)
   {
   // here ri is only a temporary space
   // and ra(set) is updated with the extrinsic information for that set
   for(int set=0; set<sets; set++)
      bcjr_wrap(set, ra(set), ri, ra(set));
   // work in ri the sum of all extrinsic information
   for(int t=0; t<tau; t++)
      for(int x=0; x<K; x++)
         {
         ri(t, x) = 1;
         for(int set=0; set<sets; set++)
            ri(t, x) *= ra(set)(t, x);
         }
   // compute the next-stage a priori information by subtracting the extrinsic
   // information of the current stage from the sum of all extrinsic information.
   // for stability we divide this sum by the number of elements making it up (that
   // is, in practice we work the average not the sum)
   {
   for(int set=0; set<sets; set++)
      for(int t=0; t<tau; t++)
         for(int x=0; x<K; x++)
            ra(set)(t, x) = pow(ri(t, x) / ra(set)(t, x), 1/double(sets-1));
   }
   // add the channel information to the sum of extrinsic information
   {
   for(int t=0; t<tau; t++)
      for(int x=0; x<K; x++)
         ri(t, x) *= r(0)(t, x);
   }
   }

// encoding and decoding functions

template <class real> void turbo<real>::seed(const int s)
   {
   for(int set=1; set<sets; set++)
      inter(set-1)->seed(s+set);
   }

template <class real> void turbo<real>::encode(vector<int>& source, vector<int>& encoded)
   {
   // Initialise result vector
   encoded.init(tau);

   // Advance interleavers to the next block
   for(int set=1; set<sets; set++)
      inter(set-1)->advance();

   // Allocate space for the encoder outputs
   matrix<int> x(sets, tau);
   // Allocate space for the interleaved sources
   vector<int> source2(tau);

   // Pass original source through encoder (necessary to know the required tail bits)
   encoder->reset(0);
   for(int t=0; t<tau; t++)
      x(0, t) = encoder->step(source(t)) / K;

   // check that encoder finishes in state zero (applies for all interleaver)
   if(endatzero && encoder->state() != 0)
      cerr << "DEBUG ERROR (turbo): Invalid finishing state for set 0 encoder - " << encoder->state() << "\n";

   // Consider the remaining sets
   {
   for(int set=1; set<sets; set++)
      {
      // Create interleaved source
      inter(set-1)->transform(source, source2);
   
      // Encode interleaved source
      encoder->reset(0);
      for(int t=0; t<tau; t++)
         x(set, t) = encoder->step(source2(t)) / K;

      // check that encoder finishes in state zero (applies for all interleaver)
      if(endatzero && encoder->state() != 0)
         cerr << "DEBUG ERROR (turbo): Invalid finishing state for set " << set << " encoder - " << encoder->state() << "\n";
      }
   }
      
   // Encode source stream
   {
   for(int t=0; t<tau; t++)
      {
      // data bits
      encoded(t) = source(t);
      // parity bits
      for(int set=0, mul=K; set<sets; set++, mul*=P)
         encoded(t) += x(set, t)*mul;
      }
   }
   }

template <class real> void turbo<real>::translate(const matrix<double>& ptable)
   {
   // Compute factors / sizes & check validity
   const int S = ptable.ysize();
   const int sp = round(log(double(P))/log(double(S)));
   const int sk = round(log(double(K))/log(double(S)));
   const int s = sk + sets*sp;
   if(P != pow(S, sp) || K != pow(S, sk))
      {
      cerr << "FATAL ERROR (turbo): each encoder parity (" << P << ") and input (" << K << ")";
      cerr << " must be represented by an integral number of modulation symbols (" << S << ").";
      cerr << " Suggested number of mod. symbols/encoder input and parity were (" << sp << "," << sk << ").\n";
      exit(1);
      }
   if(ptable.xsize() != tau*s)
      {
      cerr << "FATAL ERROR (turbo): demodulation table should have " << tau*s;
      cerr << " symbols, not " << ptable.xsize() << ".\n";
      exit(1);
      }

   // initialise memory if necessary
   if(!initialised)
      allocate();

   // Allocate space for temporary matrices
   matrix3<double> p(sets, tau, P);

   // Get the necessary data from the channel
   for(int t=0; t<tau; t++)
      {
      // Input (data) bits [set 0 only]
      for(int x=0; x<K; x++)
         {
         r(0)(t, x) = 1;
         for(int i=0, thisx = x; i<sk; i++, thisx /= S)
            r(0)(t, x) *= ptable(t*s+i, thisx % S);
         }
      // Parity bits [all sets]
      {
      for(int x=0; x<P; x++)
         for(int set=0, offset=sk; set<sets; set++)
            {
            p(set, t, x) = 1;
            for(int i=0, thisx = x; i<sp; i++, thisx /= S)
               p(set, t, x) *= ptable(t*s+i+offset, thisx % S);
            offset += sp;
            }
      }
      }

   /*
   // Handle tail parity for simile interleavers
   if(simile)
      {
      // check if the puncturing pattern is odd/even in the tail section
      bool is_stippled = true;
      for(int t=tau-m; t<tau; t++)
         for(int set=1; set<sets; set++)
            if(punc->transmit(set,t) != ((set-1)%(s-1) == t%(s-1)))
               is_stippled = false;

      // copy over the probabilities for the punctured bits from unpunctured ones
      if(is_stippled)
         {
         static bool print_debug = false;
         if(!print_debug)
            {
            cerr << "DEBUG: doing modifier for simile interleavers with stippled puncturing.\n";
            print_debug = true;
            }
         for(int t=tau-m; t<tau; t++)
            {
            int base = t%sets;
            for(int set=1; set<sets; set++)
               for(int x=0; x<P; x++)
                  p((base+set)%sets, t, x) = p(base, t, x);
            }
         }
      }
   */

   // Initialise a priori probabilities (extrinsic)
   for(int set=0; set<(parallel ? sets : 1); set++)
      for(int t=0; t<tau; t++)
         for(int x=0; x<K; x++)
            ra(set)(t, x) = 1.0/double(K);

   // Compute a priori probabilities (intrinsic - source)
   {
   for(int set=1; set<sets; set++)
      inter(set-1)->transform(r(0), r(set));
   }

   // Compute a priori probabilities (intrinsic - encoded)
   {
   for(int set=0; set<sets; set++)
      for(int t=0; t<tau; t++)
         for(int x=0; x<N; x++)
            R(set)(t, x) = r(set)(t, x%K) * p(set, t, x/K);
   }
   }
   
template <class real> void turbo<real>::decode(vector<int>& decoded)
   {
   // Initialise result vector
   decoded.init(tau);

   // initialise memory if necessary
   if(!initialised)
      allocate();

   // do one iteration, in serial or parallel as required
   if(parallel)
      decode_parallel(ri);
   else
      decode_serial(ri);

   // Decide which input sequence was most probable, based on BCJR stats.
   hard_decision(ri, decoded);
   }

// description output

template <class real> string turbo<real>::description() const
   {
   ostringstream sout;
   sout << "Turbo Code (" << output_bits() << "," << input_bits() << ") - ";
   sout << encoder->description() << ", ";
   sout << inter(0)->description() << ", ";
   sout << (endatzero ? "Terminated, " : "Unterminated, ");
   sout << (simile ? "Simile, " : "Non-simile, ");
   sout << (parallel ? "Parallel Decoding" : "Serial Decoding");
   return sout.str();
   }

// object serialization - saving

template <class real> ostream& turbo<real>::serialize(ostream& sout) const
   {
   sout << encoder;
   sout << tau << "\n";
   sout << sets << "\n";
   for(int i=0; i<inter.size(); i++)
      sout << inter(i);
   sout << int(simile) << "\n";
   sout << int(endatzero) << "\n";
   sout << int(parallel) << "\n";
   sout << iter << "\n";
   return sout;
   }

// object serialization - loading

template <class real> istream& turbo<real>::serialize(istream& sin)
   {
   int temp;
   free();
   sin >> encoder;
   sin >> tau;
   sin >> sets;
   inter.init(sets-1);
   for(int i=0; i<inter.size(); i++)
      sin >> inter(i);
   sin >> temp;
   simile = temp != 0;
   sin >> temp;
   endatzero = temp != 0;
   sin >> temp;
   parallel = temp != 0;
   sin >> iter;
   init();
   return sin;
   }

// Explicit Realizations

#define VERSION 2.20

#include "mpreal.h"
template class turbo<mpreal>;
template <> const serializer turbo<mpreal>::shelper = serializer("codec", "turbo<mpreal>", turbo<mpreal>::create);
template <> const vcs turbo<mpreal>::version = vcs("Base Turbo Decoder module (turbo<mpreal>)", VERSION);

#include "mpgnu.h"
template class turbo<mpgnu>;
template <> const serializer turbo<mpgnu>::shelper = serializer("codec", "turbo<mpgnu>", turbo<mpgnu>::create);
template <> const vcs turbo<mpgnu>::version = vcs("Base Turbo Decoder module (turbo<mpgnu>)", VERSION);

#include "logreal.h"
template class turbo<logreal>;
template <> const serializer turbo<logreal>::shelper = serializer("codec", "turbo<logreal>", turbo<logreal>::create);
template <> const vcs turbo<logreal>::version = vcs("Base Turbo Decoder module (turbo<logreal>)", VERSION);

#include "logrealfast.h"
template class turbo<logrealfast>;
template <> const serializer turbo<logrealfast>::shelper = serializer("codec", "turbo<logrealfast>", turbo<logrealfast>::create);
template <> const vcs turbo<logrealfast>::version = vcs("Base Turbo Decoder module (turbo<logrealfast>)", VERSION);
