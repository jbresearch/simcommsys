#ifndef __crypt_h
#define __crypt_h

#include "config.h"
#include "vcs.h"
#include "vector.h"

#include <string>
#include <iostream>
using namespace std;

/*
  Version 0.01 (28 Feb 2003)
  initial version - class that implements UNIX Crypt Algorithm, built by
  following the Cygwin (GNU) sources; intended for major upgrade.
*/
class crypt {
   static const vcs version;
   // constants - scalars
   static const int BS, BS2, KS, KS2, IS, IS2;
   // constants - vectors & matrices
   static const char PC1[];
   static const char PC2[];
   static const char IP[];
   static const char EP[];
   static const char E0[];
   static const char PERM[];
   static const char S_BOX[][64];
   // working spaces
   char E[48];
   char schluessel[16][48];
public:
   // basic constructor/destructor
	crypt();
	virtual ~crypt();
   // public functions
   void encrypt(char *nachr, int decr);
   void setkey(char *schl);
   char *crypttext(const char *wort, const char *salt);
protected:
   // private functions
   static void perm(char *a, const char *e, const char *pc, int n);
   void crypt_main(char *nachr_l, char *nachr_r, char *schl);
};

#endif
