#ifndef __sha_h
#define __sha_h

#include "config.h"
#include "vcs.h"
#include "vector.h"

#include <string>
#include <iostream>
using namespace std;

/*
  Version 1.00 (19 Sep 2002)
  initial version - class that implements Secure Hash Algorithm, as specified in
  Schneier, "Applied Cryptography", 1996, pp.442-445.

  Version 1.01 (20 Sep 2002)
  added comparison functions; added conversion to/from strings.

  Version 1.02 (03 Jul 2003)
  cleaned up nonlinear function implementation - now everything is done in function
  'f', instead of calling one of four functions from there.

  Version 1.03 (04 Jul 2003)
  fixed bug in string() operator.

  Version 1.04 (5 Jul 2003)
  * fixed an obscure bug in the conversion from (signed) char to int32u
*/
class sha {
   static const vcs version;
   // additive constants
   static const int32u K[];
   // current hash value
   vector<int32u> m_hash;
   // size of message so far (used for termination)
   int64u m_size;
#ifdef _DEBUG
   // debugging variables
   bool m_padded, m_terminated;
#endif
public:
   // basic constructor/destructor
	sha();
	virtual ~sha();
   // conversion to/from strings
	sha(const string& s);
   operator string() const;
   // public interface for computing digest
	void reset();
   void process(const vector<int32u>& M);
   void process(const char *buf, const int size);
   void process(istream& sin);
   // comparison functions
   bool operator>(const sha& x) const;
   bool operator<(const sha& x) const;
   bool operator==(const sha& x) const;
   bool operator!=(const sha& x) const;
protected:
   // nonlinear functions
	static int32u f(const int t, const int32u X, const int32u Y, const int32u Z);
   // circular shift
	static int32u cshift(const int32u x, const int s);
   // message expander
   static void expand(const vector<int32u>& M, vector<int32u>& W);
   // stream input/output
   friend ostream& operator<<(ostream& sout, const sha& x);
   friend istream& operator>>(istream& sin, sha& x);
};

#endif
