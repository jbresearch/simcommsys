#ifndef __bcjr_h
#define __bcjr_h

#include "config.h"
#include "vcs.h"
#include "sigspace.h"
#include "vector.h"
#include "matrix.h"
#include "matrix3.h"
#include "fsm.h"
#include <math.h>
#include <iostream>
#include <fstream>
using namespace std;

/*!
\brief   Class implementing the BCJR decoding algorithm.
\author  Johann Briffa

  All internal metrics are held as type 'real', which is user-defined. This allows internal working
  at any required level of accuracy. This is required because the internal matrics have a very wide
  dynamic range, which increases exponentially with block size 'tau'. Actually, the required range
  is within [1,0), but very large exponents are required.

  Version 2.00 (26 Feb 1999)
  updated by redefining the gamma matrix to contain only the connected set of mdash,m (reducing memory
  by a factor of M/K) and by computing alpha and beta accordingly (a speedup of M/K).

  Version 2.10 (4 Mar 1999)
  memory is only allocated in the first call to "decode". This is more efficient for the MPI strategy
  with a root server which only collects results.

  Version 2.20 (5 Mar 1999)
  modified the definition of nu (defined it as 0 for endatzero==false), in order to work out the gamma
  matrix correctly. Note that all previous results are invalid for endatzero==false!

  Version 2.30 (8 Mar 1999)
  added a faster decode routine (fdecode) which does not produce a posteriori statistics on the
  decoder's output.

  Version 2.31 (8 Mar 1999)
  optimised fdecode (reordered the summation).

  Version 2.40 (1 Sep 1999)
  fixed a bug in the work_gamma procedure - now the gamma values are worked out as specified by the
  equation, tail or no tail. The BCJR algorithm handles tail regions automatically by giving the correct
  boundary conditions for alpha/beta. Actually, the difference in this bugfix will be seen in the use
  with Turbo codes only because the only real problem is with the lack of using APP in the tail region.
  
  Version 2.41 (24 Oct 2001)
  moved most functions to the cpp file rather than the header, in order to be able to
  compile the header with Microsoft Extensions. Naturally compilation is faster, but this
  also requires realizations of the class within the cpp file. This was done for mpreal,
  mpgnu and logreal.

  Version 2.42 (23 Feb 2002)
  made some minor changes to work_results(ri) to speed up things a little.

  Version 2.43 (1 Mar 2002)   
  edited the classes to be compileable with Microsoft extensions enabled - in practice,
  the major change is in for() loops, where MS defines scope differently from ANSI.
  Rather than taking the loop variables into function scope, we chose to wrap around the
  offending for() loops.

  Version 2.44 (6 Mar 2002)
  changed use of iostream from global to std namespace.

  Version 2.45 (13 Mar 2002)
  added protected init() function and default constructor, which allow derived classes
  to be re-used (needed for serialization).

  Version 2.46 (4 Apr 2002)
  removed 'inline' keyword from internal functions and procedures. Also made version variable
  a private static const member.

  Version 2.47 (18 Apr 2005)
  removed internal temporary arrays 'rri' and 'rro'. Since the matrix and vector classes
  have been optimised (and only do range checking in the Debug build), there is no real
  need to use arrays any more. This makes the code cleaner and less error-prone.
  Also cleaned up the 'work_results(ri,ro)' function, so that the results are accumulated
  into a double value; this mirrirs the way that 'work_results(ri)' works.

  Version 2.50 (18 Apr 2005)
  added a second template class 'dbl', which defaults to 'double', to allow other
  numerical representations for externally-transferred statistics. This became necessary
  for the parallel decoding structure, where the range of extrinsic information is much
  larger than for serial decoding; furthermore, this range increases with the number of
  iterations performed.

\warning Static memory requirements: sizeof(real)*(2*(tau+1)*M + tau*M*K + K + N) + sizeof(int)*(2*K+1)*M
\warning Dynamic memory requirements: none
*/
template <class real, class dbl=double> class bcjr {
   static const vcs version;
   // internal variables
   int   tau;  //!< Block size in symbols (including any tail bits)
   int   K;    //!< Number of possible input to encoder at any time instant (equals 2^k)
   int   N;    //!< Number of possible outputs of encoder at any time instant (equals 2^n)
   int   M;    //!< Number of possible states of the encoder
   int   nu;   //!< Length of tail in symbols (derived from encoder's memoery order)
   bool  initialised;   //!< Initially false, becomes true after the first call to "decode" when memory is allocated
   bool  startatzero;   //!< True to indicate that the trellis starts in state zero
   bool  endatzero;     //!< True to indicate that the trellis ends in state zero
   // working matrices
   matrix<real>	alpha;   //!< Forward recursion metric: alpha(t,m) = Pr{S(t)=m, Y(1..t)}
   matrix<real>   beta;    //!< Backward recursion metric: beta(t,m) = Pr{Y(t+1..tau) | S(t)=m}
   matrix3<real>	gamma;   //!< Receiver metric: gamma(t-1,m',i) = Pr{S(t)=m(m',i), Y(t) | S(t-1)=m'}
   // temporary arrays/matrices
   matrix<int>    lut_X;   //!< lut_X(m,i) = encoder output if system was in state 'm' and given input 'i'
   matrix<int>    lut_m;   //!< lut_m(m,i) = next state of encoder if system was in state 'm' and given input 'i'
   vector<int>    lut_i;   //!< lut_i(m) = required input to tail off a system in state 'm'
   // memory allocator (for internal use only)
   void allocate();
   // internal functions
   real lambda(const int t, const int m);
   real sigma(const int t, const int m, const int i);
   // internal procedures
   void work_gamma(matrix<dbl>& R);
   void work_gamma(matrix<dbl>& R, matrix<dbl>& app);
   void work_alpha();
   void work_beta();
   void work_results(matrix<dbl>& ri, matrix<dbl>& ro);
   void work_results(matrix<dbl>& ri);
protected:
   void init(fsm& encoder, const int tau, const bool startatzero, const bool endatzero);
   bcjr();
public:
   // constructor & destructor
   bcjr(fsm& encoder, const int tau, const bool startatzero =true, const bool endatzero =true);
   ~bcjr();
   // decode functions
   void decode(matrix<dbl>& R, matrix<dbl>& ri, matrix<dbl>& ro);
   void decode(matrix<dbl>& R, matrix<dbl>& app, matrix<dbl>& ri, matrix<dbl>& ro);
   void fdecode(matrix<dbl>& R, matrix<dbl>& ri);
   void fdecode(matrix<dbl>& R, matrix<dbl>& app, matrix<dbl>& ri);
};

#endif

