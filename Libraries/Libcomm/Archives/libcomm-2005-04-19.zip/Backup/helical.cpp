#include "helical.h"
#include <stdlib.h>
#include <sstream>
using namespace std;

const vcs helical::version("Helical Interleaver module (helical)", 1.30);

const serializer helical::shelper("interleaver", "helical", helical::create);

// initialisation functions

void helical::init(const int tau, const int rows, const int cols)
   {
   helical::rows = rows;
   helical::cols = cols;

   int blklen = rows*cols;
   if(blklen > tau)
      {
      cerr << "FATAL ERROR (helical): Interleaver block size cannot be greater than BCJR block.\n";
      exit(1);
      }
   lut.init(tau);
   int row = rows-1, col = 0;
   int i;
   for(i=0; i<blklen; i++)
      {
      lut(i) = row*cols + col;
      row = (row-1+rows) % rows;
      col = (col+1) % cols;
      }
   for(i=blklen; i<tau; i++)
      lut(i) = i;
   }

// description output

string helical::description() const
   {
   ostringstream sout;
   sout << "Helical " << rows << "x" << cols << " Interleaver";
   return sout.str();
   }

// object serialization - saving

ostream& helical::serialize(ostream& sout) const
   {
   sout << lut.size() << "\n";
   sout << rows << "\n";
   sout << cols << "\n";
   return sout;
   }

// object serialization - loading

istream& helical::serialize(istream& sin)
   {
   int tau;
   sin >> tau;
   sin >> rows;
   sin >> cols;
   init(tau, rows, cols);
   return sin;
   }

