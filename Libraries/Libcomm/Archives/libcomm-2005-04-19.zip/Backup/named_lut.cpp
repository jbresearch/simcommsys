#include "named_lut.h"
#include <sstream>
using namespace std;

const vcs named_lut::version("Named LUT Interleaver module (named_lut)", 1.10);

const serializer named_lut::shelper("interleaver", "named", named_lut::create);

// description output

string named_lut::description() const
   {
   ostringstream sout;
   sout << "Named Interleaver (" << lutname;
   if(m > 0)
      sout << ", Forced tail length " << m << ")";
   else
      sout << ")";
   return sout.str();
   }

// object serialization - saving

ostream& named_lut::serialize(ostream& sout) const
   {
   sout << m << "\n";
   sout << lutname << "\n";
   sout << lut;
   return sout;
   }

// object serialization - loading

istream& named_lut::serialize(istream& sin)
   {
   sin >> m;
   sin >> lutname;
   sin >> lut;
   return sin;
   }
