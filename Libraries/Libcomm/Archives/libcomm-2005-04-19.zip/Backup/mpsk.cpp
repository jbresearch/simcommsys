#include "mpsk.h"
#include <math.h>
#include <sstream>
using namespace std;

const vcs mpsk::version("M-PSK Modulator module (mpsk)", 2.00);

const serializer mpsk::shelper("modulator", "mpsk", mpsk::create);


// initialization

void mpsk::init(const int m)
   {
   map.init(m);
   // allocate symbols sequentially - this has to be changed
   // to use set-partitioning (for error-minimization)
   for(int i=0; i<m; i++)
      {
      const double r = 1;
      const double theta = i * (2*PI/m);
      map(i) = sigspace(r*cos(theta), r*sin(theta));
      }
   }

// description output

string mpsk::description() const
   {
   ostringstream sout;
   switch(map.size())
      {
      case 2:
         sout << "BPSK modulator";
         break;
      case 4:
         sout << "QPSK modulator";
         break;
      default:
         sout << map.size() << "PSK modulator";
         break;
      }
   return sout.str();
   }

// object serialization - saving

ostream& mpsk::serialize(ostream& sout) const
   {
   sout << map.size();
   return sout;
   }

// object serialization - loading

istream& mpsk::serialize(istream& sin)
   {
   int m;
   sin >> m;
   init(m);
   return sin;
   }
