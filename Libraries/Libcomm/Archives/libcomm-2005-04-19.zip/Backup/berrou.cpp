#include "berrou.h"
#include <stdlib.h>
#include <sstream>
using namespace std;

const vcs berrou::version("Berrou's Original Interleaver module (berrou)", 1.30);

const serializer berrou::shelper("interleaver", "berrou", berrou::create);

// initialization

void berrou::init(const int M)
   {
   berrou::M = M;

   if(weight(M) != 1)
      {
      cerr << "FATAL ERROR (berrou): M must be an integral power of 2.\n";
      exit(1);
      }
   int tau = M*M;
   lut.init(tau);
   const int P[] = {17, 37, 19, 29, 41, 23, 13, 7};
   for(int i=0; i<M; i++)
      for(int j=0; j<M; j++)
         {
         int ir = (M/2+1)*(i+j) % M;
         int xi = (i+j) % 8;
         int jr = (P[xi]*(j+1) - 1) % M;
         lut(i*M+j) = ir*M + jr;
         }
   }

// description output

string berrou::description() const
   {
   ostringstream sout;
   sout << "Berrou Interleaver (" << M << "x" << M << ")";
   return sout.str();
   }

// object serialization - saving

ostream& berrou::serialize(ostream& sout) const
   {
   sout << M << "\n";
   return sout;
   }

// object serialization - loading

istream& berrou::serialize(istream& sin)
   {
   sin >> M;
   init(M);
   return sin;
   }
