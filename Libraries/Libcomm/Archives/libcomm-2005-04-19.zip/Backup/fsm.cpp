#include "fsm.h"
#include "serializer.h"

const vcs fsm::version("Finite State Machine module (fsm)", 1.40);

const int fsm::tail = -1;

// serialization functions

ostream& operator<<(ostream& sout, const fsm* x)
   {
   sout << x->name() << "\n";
   x->serialize(sout);
   return sout;
   }

istream& operator>>(istream& sin, fsm*& x)
   {
   string name;
   sin >> name;
   x = (fsm*) serializer::call("fsm", name);
   if(x == NULL)
      {
      cerr << "FATAL ERROR (fsm): Type \"" << name << "\" unknown.\n";
      exit(1);
      }
   x->serialize(sin);
   return sin;
   }
