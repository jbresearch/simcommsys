#ifndef __md5_h
#define __md5_h

#include "config.h"
#include "vcs.h"
#include "vector.h"

#include <string>
#include <iostream>
using namespace std;

/*
  Version 1.00 (03 Jul 2003)
  initial version - class that implements Message Digest MD5, as specified in
  Schneier, "Applied Cryptography", 1996, pp.436-441.
  Included comparison functions; added conversion to/from strings.

  Version 1.01 (04 Jul 2003)
  fixed bug in string() operator.

  Version 1.02 (04 Jul 2003)
  fixed bugs in Schneier's descriptions of MD5:
  * chaining variables should be initialised like SHA's
  * message length is low-order byte first
  * message is encoded into 32-bit words in low-order byte first

  Version 1.03 (05 Jul 2003)
  added information function to return message size

  Version 1.04 (5 Jul 2003)
  * added self-testing on creation of the first object.
  * fixed an obscure bug in the conversion from (signed) char to int32u
*/
class md5 {
   static const vcs version;
   // static variables
   static bool tested;
   // additive constants
   static vector<int32u> t;
   // rotational constants
   static const int s[];
   // message index constants
   static const int ndx[];
   // current hash value
   vector<int32u> m_hash;
   // size of message so far (used for termination)
   int64u m_size;
#ifdef _DEBUG
   // debugging variables
   bool m_padded, m_terminated;
#endif
public:
   // basic constructor/destructor
	md5();
	virtual ~md5();
   // conversion to/from strings
	md5(const string& s);
   operator string() const;
   // public interface for computing digest
	void reset();
   void process(const vector<int32u>& M);
   void process(const char *buf, const int size);
   void process(istream& sin);
   // information functions
   int64u size() const { return m_size; };
   // comparison functions
   bool operator>(const md5& x) const;
   bool operator<(const md5& x) const;
   bool operator==(const md5& x) const;
   bool operator!=(const md5& x) const;
protected:
   // verification function
   bool verify(const string message, const string hash);
   // circular shift
	static int32u cshift(const int32u x, const int s);
   // nonlinear functions
   static int32u f(const int i, const int32u X, const int32u Y, const int32u Z);
   // step operation
   static int32u op(const int i, const int32u a, const int32u b, const int32u c, const int32u d, const vector<int32u>& M);
   // stream input/output
   friend ostream& operator<<(ostream& sout, const md5& x);
   friend istream& operator>>(istream& sin, md5& x);
};

#endif
