#include "rectangular.h"
#include <stdlib.h>
#include <sstream>
using namespace std;

const vcs rectangular::version("Rectangular Interleaver module (rectangular)", 1.30);

const serializer rectangular::shelper("interleaver", "rectangular", rectangular::create);


// initialisation functions

void rectangular::init(const int tau, const int rows, const int cols)
   {
   rectangular::rows = rows;
   rectangular::cols = cols;

   int blklen = rows*cols;
   if(blklen > tau)
      {
      cerr << "FATAL ERROR (rectangular): Interleaver block size cannot be greater than BCJR block.\n";
      exit(1);
      }
   lut.init(tau);
   int row = 0, col = 0;
   int i;
   for(i=0; i<blklen; i++)
      {
      row = i % rows;
      col = i / rows;
      lut(i) = row*cols + col;
      }
   for(i=blklen; i<tau; i++)
      lut(i) = i;
   }
   
// description output

string rectangular::description() const
   {
   ostringstream sout;
   sout << "Rectangular " << rows << "x" << cols << " Interleaver";
   return sout.str();
   }

// object serialization - saving

ostream& rectangular::serialize(ostream& sout) const
   {
   sout << lut.size() << "\n";
   sout << rows << "\n";
   sout << cols << "\n";
   return sout;
   }

// object serialization - loading

istream& rectangular::serialize(istream& sin)
   {
   int tau;
   sin >> tau;
   sin >> rows;
   sin >> cols;
   init(tau, rows, cols);
   return sin;
   }

