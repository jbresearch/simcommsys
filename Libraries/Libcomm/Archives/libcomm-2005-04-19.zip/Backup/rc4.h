#ifndef __rc4_h
#define __rc4_h

#include "config.h"
#include "vcs.h"
#include "vector.h"

#include <string>
using namespace std;

/*
  Version 1.00 (03 Jul 2003)
  initial version - class that implements RSA RC4 Algorithm, as specified in
  Schneier, "Applied Cryptography", 1996, pp.397-398.

  Version 1.01 (04 Jul 2003)
  changed vector tables to int8u instead of int, to ensure validity of values.

  Version 1.02 (5 Jul 2003)
  * added self-testing on creation of the first object.
  * modified counters to be int8u instead of int - also renamed them x & y
  * removed superfluous mod 256 (& 0xff) operations
*/
class rc4 {
   static const vcs version;
   // static variables
   static bool tested;
   // working spaces
   vector<int8u> S;
   int8u x,y;
public:
   // basic constructor/destructor
	rc4();
	virtual ~rc4();
   // public functions
   void init(string key);
   string encrypt(const string plaintext);
   int8u encrypt(const int8u plaintext);
protected:
   // private functions
   bool verify(const string key, const string plaintext, const string ciphertext);
};

#endif
