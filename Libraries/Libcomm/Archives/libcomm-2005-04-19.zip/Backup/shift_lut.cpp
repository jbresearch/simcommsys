#include "shift_lut.h"
#include <sstream>
using namespace std;

const vcs shift_lut::version("Barrel-Shifting LUT Interleaver module (shift_lut)", 1.30);

const serializer shift_lut::shelper("interleaver", "shift", shift_lut::create);


// initialisation functions

void shift_lut::init(const int amount, const int tau)
   {
   shift_lut::amount = amount;

   lut.init(tau);
   for(int i=0; i<tau; i++)
      lut(i) = (i + amount) % tau;
   }

// description output

string shift_lut::description() const
   {
   ostringstream sout;
   sout << "Shift by " << amount << " Interleaver";
   return sout.str();
   }

// object serialization - saving

ostream& shift_lut::serialize(ostream& sout) const
   {
   sout << lut.size() << "\n";
   sout << amount << "\n";
   return sout;
   }

// object serialization - loading

istream& shift_lut::serialize(istream& sin)
   {
   int tau, amount;
   sin >> tau >> amount;
   init(amount, tau);
   return sin;
   }
