#include "interleaver.h"
#include "serializer.h"

const vcs interleaver::version("Interleaver Base module (interleaver)", 1.50);

// serialization functions

ostream& operator<<(ostream& sout, const interleaver* x)
   {
   sout << x->name() << "\n";
   x->serialize(sout);
   return sout;
   }

istream& operator>>(istream& sin, interleaver*& x)
   {
   string name;
   sin >> name;
   x = (interleaver*) serializer::call("interleaver", name);
   if(x == NULL)
      {
      cerr << "FATAL ERROR (interleaver): Type \"" << name << "\" unknown.\n";
      exit(1);
      }
   x->serialize(sin);
   return sin;
   }
