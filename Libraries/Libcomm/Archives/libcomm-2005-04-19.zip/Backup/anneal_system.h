#ifndef __anneal_system_h
#define __anneal_system_h

#include "config.h"
#include "vcs.h"
#include <iostream>
using namespace std;

/*!   \brief   A virtual class defining a simulated annealing system.
      \author  Johann Briffa
      \date    10 July 1998
      \version 1.00

  Version 1.10 (11 Oct 2001)
  added a virtual function which outputs the annealed system
  (this was only done before in the destruction mechanism)

  Version 1.11 (26 Oct 2001)
  added a virtual destroy function (see interleaver.h)

  Version 1.20 (4 Nov 2001)
  added a stream << operator and modified the regular output routine accordingly
  (so that this now returns the stream, and is a pure virtual).

  Version 1.21 (6 Mar 2002)
  changed vcs version variable from a global to a static class variable.
  also changed use of iostream from global to std namespace.
*/
class anneal_system {
   static const vcs version;
public:
   //! Seeds all random generators used in the annealer
   virtual void seed(const int s) = 0;
   //! Perturbs the state and returns the difference in energy due to perturbation
   virtual double perturb() = 0;
   //! Undoes the last perturbation (guaranteed only for one stage)
   virtual void unperturb() = 0;
   //! Returns the system's energy content
   virtual double energy() = 0;
   //! Outputs the system to an output stream
   virtual ostream& output(ostream& sout) const = 0;
   friend ostream& operator<<(ostream& sout, const anneal_system& x);
};

#endif
