#ifndef __fsm_h
#define __fsm_h

#include "config.h"
#include "vcs.h"
#include <iostream>
#include <string>
using namespace std;

/*
  Version 1.10 (4 Nov 2001)
  added a virtual function which outputs details on the finite state machine (this was 
  only done before in a non-standard print routine). Added a stream << operator too.

  Version 1.20 (28 Feb 2002)
  added serialization facility

  Version 1.21 (6 Mar 2002)
  changed vcs version variable from a global to a static class variable.
  also changed use of iostream from global to std namespace.

  Version 1.22 (11 Mar 2002)
  changed the definition of the cloning operation to be a const member.

  Version 1.30 (11 Mar 2002)
  changed the stream << and >> functions to conform with the new serializer protocol,
  as defined in serializer 1.10. The stream << output function first writes the name
  of the derived class, then calls its serialize() to output the data. The name is
  obtained from the virtual name() function. The stream >> input function first gets
  the name from the stream, then (via serialize::call) creates a new object of the
  appropriate type and calls its serialize() function to get the relevant data. Also,
  changed the definition of stream << output to take the pointer to the fsm class
  directly, not by reference.

  Version 1.40 (27 Mar 2002)
  removed the descriptive output() and related stream << output functions, and replaced
  them by a function description() which returns a string. This provides the same
  functionality but in a different format, so that now the only stream << output
  functions are for serialization. This should make the notation much clearer while
  also simplifying description display in objects other than streams.
*/
class fsm {
   static const vcs version;
public:
   static const int tail;				      // a special input to use when tailing out
   
   virtual ~fsm() {};					      // virtual destructor
   virtual fsm *clone() const = 0;			// cloning operation
   virtual const char* name() const = 0;  // derived object's name

   virtual void reset(int state=0) = 0;	// resets the FSM to a specified state
   virtual int step(int& input) = 0;		// feeds the specified input and returns the corresponding output
   virtual int state() const = 0;		   // returns the current state
   virtual int num_states() const = 0;	   // returns the number of defined states
   virtual int num_inputs() const = 0;	   // returns the number of valid inputs
   virtual int num_outputs() const = 0;	// returns the number of valid outputs
   virtual int mem_order() const = 0;	   // memory order (length of tail)

   // description output
   virtual string description() const = 0;
   // object serialization - saving
   virtual ostream& serialize(ostream& sout) const = 0;
   friend ostream& operator<<(ostream& sout, const fsm* x);
   // object serialization - loading
   virtual istream& serialize(istream& sin) = 0;
   friend istream& operator>>(istream& sin, fsm*& x);
};

#endif

