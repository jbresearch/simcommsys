#include "channel.h"
#include "serializer.h"

const vcs channel::version("Channel Base module (channel)", 1.31);

// transmission function

void channel::transmit(const vector<sigspace>& tx, vector<sigspace>& rx)
   {
   // Initialize results vector
   rx.init(tx);
   // Corrupt the modulation symbols (simulate the channel)
   for(int i=0; i<tx.size(); i++)
      rx(i) = corrupt(tx(i));
   }

// serialization functions

ostream& operator<<(ostream& sout, const channel* x)
   {
   sout << x->name() << "\n";
   x->serialize(sout);
   return sout;
   }

istream& operator>>(istream& sin, channel*& x)
   {
   string name;
   sin >> name;
   x = (channel*) serializer::call("channel", name);
   if(x == NULL)
      {
      cerr << "FATAL ERROR (channel): Type \"" << name << "\" unknown.\n";
      exit(1);
      }
   x->serialize(sin);
   return sin;
   }
